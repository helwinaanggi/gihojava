const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const PASSWORD_MIN = 10;
// bcrypt hanya memakai 72 byte pertama; tolak yang lebih panjang supaya tidak terpotong diam-diam.
export const PASSWORD_MAX_BYTES = 72;

export function normalizeEmail(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function passwordProblem(password, email) {
  if (typeof password !== 'string') return 'Kata sandi wajib diisi.';
  if (password.length < PASSWORD_MIN) return `Kata sandi minimal ${PASSWORD_MIN} karakter.`;
  if (Buffer.byteLength(password, 'utf8') > PASSWORD_MAX_BYTES) return 'Kata sandi terlalu panjang (maksimal 72 byte).';
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) return 'Kata sandi harus mengandung huruf dan angka.';
  if (email && password.toLowerCase() === email) return 'Kata sandi tidak boleh sama dengan email.';
  return null;
}

// Hanya field yang dikenal yang diambil (mencegah mass assignment, mis. role).
export function validateRegistration(body) {
  const input = body && typeof body === 'object' ? body : {};
  const fields = {};

  const name = typeof input.name === 'string' ? input.name.trim().replace(/\s+/g, ' ') : '';
  if (name.length < 2 || name.length > 80) fields.name = 'Nama harus 2 sampai 80 karakter.';

  const email = normalizeEmail(input.email);
  if (!email || email.length > 254 || !EMAIL_RE.test(email)) fields.email = 'Format email tidak valid.';

  const pwProblem = passwordProblem(input.password, email);
  if (pwProblem) fields.password = pwProblem;

  if (Object.keys(fields).length > 0) return { ok: false, fields };
  return { ok: true, value: { name, email, password: input.password } };
}

export function validateLogin(body) {
  const input = body && typeof body === 'object' ? body : {};
  const email = normalizeEmail(input.email);
  const password = input.password;
  const fields = {};
  if (!email || email.length > 254) fields.email = 'Email wajib diisi.';
  if (typeof password !== 'string' || password.length === 0 || Buffer.byteLength(password, 'utf8') > 1024) {
    fields.password = 'Kata sandi wajib diisi.';
  }
  if (Object.keys(fields).length > 0) return { ok: false, fields };
  return { ok: true, value: { email, password } };
}

import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

// Aturan data ditegakkan oleh skema, bukan hanya oleh kode aplikasi.
const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT    NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
  email           TEXT    NOT NULL UNIQUE
                          CHECK (email = lower(email) AND length(email) <= 254),
  password_hash   TEXT    NOT NULL,
  role            TEXT    NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  failed_attempts INTEGER NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  locked_until    INTEGER,
  created_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
`;

export function openDb(dbPath) {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  return db;
}

export function isUniqueViolation(err) {
  return typeof err?.message === 'string' && err.message.includes('UNIQUE constraint failed');
}

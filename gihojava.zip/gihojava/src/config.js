import crypto from 'node:crypto';
import fs from 'node:fs';

// Membaca nilai rahasia dari NAMA atau NAMA_FILE (pola Docker secrets).
function readSecret(env, name) {
  const filePath = env[`${name}_FILE`];
  if (filePath) return fs.readFileSync(filePath, 'utf8').trim();
  return env[name];
}

function toInt(value, fallback) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export function loadConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const isProd = nodeEnv === 'production';

  let jwtSecret = readSecret(env, 'JWT_SECRET');
  let ephemeralSecret = false;
  if (!jwtSecret) {
    if (isProd) throw new Error('JWT_SECRET (atau JWT_SECRET_FILE) wajib diisi di production');
    jwtSecret = crypto.randomBytes(48).toString('hex');
    ephemeralSecret = true;
  }
  if (isProd && jwtSecret.length < 32) {
    throw new Error('JWT_SECRET minimal 32 karakter. Buat dengan: openssl rand -hex 48');
  }

  const trustProxy = env.TRUST_PROXY ? toInt(env.TRUST_PROXY, 0) || false : false;

  return {
    nodeEnv,
    isProd,
    port: toInt(env.PORT, 3000),
    dbPath: env.DB_PATH || './data/gihojava.db',
    jwtSecret,
    ephemeralSecret,
    jwtExpiresIn: env.JWT_EXPIRES_IN || '2h',
    bcryptRounds: toInt(env.BCRYPT_ROUNDS, 12),
    trustProxy,
    logLevel: env.LOG_LEVEL || 'info',
    metricsToken: readSecret(env, 'METRICS_TOKEN') || '',
    rateLimit: {
      apiMax: toInt(env.RATE_LIMIT_API_MAX, 300), // per menit per IP
      authMax: toInt(env.RATE_LIMIT_AUTH_MAX, 20), // per 15 menit per IP
      authWindowMs: toInt(env.RATE_LIMIT_AUTH_WINDOW_MS, 15 * 60 * 1000),
    },
    lockout: {
      maxAttempts: toInt(env.LOCKOUT_MAX_ATTEMPTS, 5),
      minutes: toInt(env.LOCKOUT_MINUTES, 15),
    },
  };
}

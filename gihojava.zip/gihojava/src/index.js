import { createApp } from './app.js';
import { loadConfig } from './config.js';

const config = loadConfig();
const { app, logger, close } = createApp(config);

if (config.ephemeralSecret) {
  logger.warn('JWT_SECRET tidak diatur: memakai secret acak sementara, semua token tidak berlaku setelah restart');
}

const server = app.listen(config.port, () => {
  logger.info('server berjalan', { port: config.port, env: config.nodeEnv });
});

// Penutupan rapi agar request yang sedang berjalan selesai dulu (penting saat deploy).
function shutdown(signal) {
  logger.info('menutup server', { signal });
  const force = setTimeout(() => process.exit(1), 10_000);
  force.unref();
  server.close(() => {
    close();
    process.exit(0);
  });
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error('unhandledRejection', { reason: String(reason) });
});

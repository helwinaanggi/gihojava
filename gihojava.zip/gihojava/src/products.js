// Data contoh. Harga dalam rupiah (bilangan bulat). Ganti dengan tabel produk sungguhan.
export const PRODUCTS = [
  { id: 'meja-makan-jati-minimalis', name: 'Meja Makan Jati Minimalis', category: 'Ruang makan', price: 6450000, dimensions: '180 × 90 × 75 cm', finishing: 'Natural', status: 'ready' },
  { id: 'kursi-makan-jati-sandaran', name: 'Kursi Makan Jati Sandaran Tinggi', category: 'Ruang makan', price: 1250000, dimensions: '45 × 50 × 95 cm', finishing: 'Walnut', status: 'ready' },
  { id: 'ranjang-jati-panel', name: 'Ranjang Jati Panel 160', category: 'Kamar tidur', price: 8900000, dimensions: '210 × 170 × 100 cm', finishing: 'Natural', status: 'preorder' },
  { id: 'bufet-tv-jati-laci', name: 'Bufet TV Jati 3 Laci', category: 'Ruang tamu', price: 5200000, dimensions: '160 × 40 × 50 cm', finishing: 'Ebony', status: 'ready' },
  { id: 'meja-kerja-jati-lipat', name: 'Meja Kerja Jati Ramping', category: 'Ruang kerja', price: 3750000, dimensions: '140 × 65 × 75 cm', finishing: 'Natural', status: 'ready' },
  { id: 'bangku-taman-jati', name: 'Bangku Taman Jati', category: 'Taman dan teras', price: 2100000, dimensions: '150 × 50 × 85 cm', finishing: 'Minyak jati', status: 'low' },
];

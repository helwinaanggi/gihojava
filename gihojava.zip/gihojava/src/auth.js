import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Router } from 'express';
import { isUniqueViolation } from './db.js';
import { validateLogin, validateRegistration } from './validation.js';

const ISSUER = 'gihojava';
const ALGORITHM = 'HS256';

const GENERIC_LOGIN_ERROR =
  'Email atau kata sandi salah, atau akun dikunci sementara setelah beberapa percobaan gagal. Coba lagi nanti.';

function apiError(res, status, code, message, fields) {
  return res.status(status).json({ error: { code, message, ...(fields ? { fields } : {}) } });
}

function publicUser(row) {
  return { id: row.id, name: row.name, email: row.email, role: row.role, createdAt: row.created_at };
}

export function createAuth({ db, config, metrics, logger }) {
  const q = {
    byEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
    byId: db.prepare('SELECT * FROM users WHERE id = ?'),
    insert: db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)'),
    fail: db.prepare(
      `UPDATE users
          SET failed_attempts = failed_attempts + 1,
              locked_until = CASE WHEN failed_attempts + 1 >= ? THEN ? ELSE locked_until END
        WHERE id = ?`
    ),
    reset: db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?'),
  };

  // Hash palsu agar waktu respons login untuk email tak dikenal mirip dengan email yang dikenal.
  const dummyHash = bcrypt.hashSync('kata-sandi-palsu-untuk-timing', config.bcryptRounds);

  function signToken(user) {
    return jwt.sign({ role: user.role }, config.jwtSecret, {
      algorithm: ALGORITHM,
      issuer: ISSUER,
      subject: String(user.id),
      expiresIn: config.jwtExpiresIn,
    });
  }

  function requireAuth(req, res, next) {
    const header = req.get('authorization') || '';
    const match = /^Bearer ([A-Za-z0-9._-]+)$/.exec(header);
    if (!match) {
      res.set('WWW-Authenticate', 'Bearer');
      return apiError(res, 401, 'UNAUTHENTICATED', 'Silakan masuk terlebih dahulu.');
    }
    try {
      const payload = jwt.verify(match[1], config.jwtSecret, { algorithms: [ALGORITHM], issuer: ISSUER });
      const id = Number(payload.sub);
      if (!Number.isSafeInteger(id)) throw new Error('subjek token tidak valid');
      req.auth = { id, role: payload.role };
      req.userId = id;
      return next();
    } catch (err) {
      metrics.authEvents.inc({ event: 'token_rejected' });
      logger.debug('token ditolak', { requestId: req.id, reason: err.name });
      res.set('WWW-Authenticate', 'Bearer error="invalid_token"');
      const expired = err.name === 'TokenExpiredError';
      return apiError(
        res,
        401,
        expired ? 'TOKEN_EXPIRED' : 'INVALID_TOKEN',
        expired ? 'Sesi Anda sudah berakhir. Silakan masuk lagi.' : 'Token tidak valid. Silakan masuk lagi.'
      );
    }
  }

  const router = Router();

  router.post('/register', async (req, res, next) => {
    try {
      const result = validateRegistration(req.body);
      if (!result.ok) return apiError(res, 422, 'VALIDATION_FAILED', 'Data pendaftaran belum valid.', result.fields);
      const { name, email, password } = result.value;

      const hash = await bcrypt.hash(password, config.bcryptRounds);
      let id;
      try {
        id = Number(q.insert.run(name, email, hash).lastInsertRowid);
      } catch (err) {
        // Kendala UNIQUE di database yang menjadi penentu, bukan cek-lalu-tulis di kode.
        if (isUniqueViolation(err)) {
          return apiError(res, 409, 'EMAIL_TAKEN', 'Email ini sudah terdaftar. Coba masuk, atau pakai email lain.', {
            email: 'Email sudah terdaftar.',
          });
        }
        throw err;
      }

      const user = q.byId.get(id);
      metrics.authEvents.inc({ event: 'register' });
      logger.info('pengguna terdaftar', { requestId: req.id, userId: id });
      return res.status(201).json({ token: signToken(user), user: publicUser(user) });
    } catch (err) {
      return next(err);
    }
  });

  router.post('/login', async (req, res, next) => {
    try {
      const result = validateLogin(req.body);
      if (!result.ok) return apiError(res, 422, 'VALIDATION_FAILED', 'Email dan kata sandi wajib diisi.', result.fields);
      const { email, password } = result.value;

      const user = q.byEmail.get(email);
      const now = Date.now();
      const locked = user && user.locked_until && user.locked_until > now;

      if (!user || locked) {
        // Tetap menghitung hash agar waktu respons seragam dan pesan galat tidak membocorkan keberadaan akun.
        await bcrypt.compare(password, dummyHash);
        metrics.authEvents.inc({ event: locked ? 'login_blocked_locked' : 'login_failed' });
        logger.warn('login gagal', { requestId: req.id, ip: req.ip, reason: locked ? 'locked' : 'unknown_email' });
        return apiError(res, 401, 'INVALID_CREDENTIALS', GENERIC_LOGIN_ERROR);
      }

      const ok = await bcrypt.compare(password, user.password_hash);
      if (!ok) {
        const lockUntil = now + config.lockout.minutes * 60 * 1000;
        q.fail.run(config.lockout.maxAttempts, lockUntil, user.id);
        const after = q.byId.get(user.id);
        const justLocked = after.locked_until && after.locked_until > now;
        metrics.authEvents.inc({ event: 'login_failed' });
        if (justLocked) metrics.authEvents.inc({ event: 'account_locked' });
        logger.warn('login gagal', {
          requestId: req.id,
          ip: req.ip,
          userId: user.id,
          reason: 'wrong_password',
          locked: Boolean(justLocked),
        });
        return apiError(res, 401, 'INVALID_CREDENTIALS', GENERIC_LOGIN_ERROR);
      }

      q.reset.run(user.id);
      metrics.authEvents.inc({ event: 'login_success' });
      logger.info('login berhasil', { requestId: req.id, userId: user.id });
      return res.json({ token: signToken(user), user: publicUser(user) });
    } catch (err) {
      return next(err);
    }
  });

  // Token bersifat stateless: logout dilakukan klien dengan menghapus token dari localStorage.
  router.get('/me', requireAuth, (req, res) => {
    const user = q.byId.get(req.auth.id);
    if (!user) {
      return apiError(res, 401, 'INVALID_TOKEN', 'Akun tidak ditemukan. Silakan masuk lagi.');
    }
    return res.json({ user: publicUser(user) });
  });

  return { router, requireAuth };
}

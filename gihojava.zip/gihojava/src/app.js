import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createAuth } from './auth.js';
import { openDb } from './db.js';
import { createLogger } from './logger.js';
import { createMetrics } from './metrics.js';
import { PRODUCTS } from './products.js';

const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const sha256 = (value) => crypto.createHash('sha256').update(value).digest();

function limiter({ windowMs, limit, code, message }) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => res.status(429).json({ error: { code, message } }),
  });
}

export function createApp(config) {
  const logger = createLogger(config.logLevel);
  const db = openDb(config.dbPath);
  const metrics = createMetrics();
  const { router: authRouter } = createAuth({ db, config, metrics, logger });

  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', config.trustProxy);

  // ID request, metrik RED, dan log akses.
  app.use((req, res, next) => {
    req.id = req.get('x-request-id')?.slice(0, 64).replace(/[^\w-]/g, '') || crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    const start = process.hrtime.bigint();
    res.on('finish', () => {
      const seconds = Number(process.hrtime.bigint() - start) / 1e9;
      const route = req.route ? `${req.baseUrl}${req.route.path}` : res.statusCode === 404 ? 'unmatched' : 'static';
      const labels = { method: req.method, route, status: res.statusCode };
      metrics.httpRequests.inc(labels);
      metrics.httpDuration.observe(labels, seconds);
      const urlPath = req.originalUrl.split('?')[0]; // tanpa query string, dan path lengkap
      const quiet = urlPath === '/healthz' || urlPath === '/metrics';
      const level = res.statusCode >= 500 ? 'error' : quiet ? 'debug' : 'info';
      logger[level]('request', {
        requestId: req.id,
        method: req.method,
        path: urlPath,
        status: res.statusCode,
        ms: Math.round(seconds * 1000),
        ip: req.ip,
        userId: req.userId,
      });
    });
    next();
  });

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", 'https://fonts.googleapis.com'],
          fontSrc: ['https://fonts.gstatic.com'],
          imgSrc: ["'self'", 'data:'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: config.isProd ? [] : null,
        },
      },
      referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    })
  );
  app.use((req, res, next) => {
    res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
  });

  // Kesehatan: benar-benar menguji database, bukan sekadar "proses hidup".
  app.get('/healthz', (req, res) => {
    try {
      db.prepare('SELECT 1').get();
      res.set('Cache-Control', 'no-store').json({ status: 'ok', uptime: Math.round(process.uptime()) });
    } catch (err) {
      logger.error('healthcheck gagal', { reason: err.message });
      res.status(503).json({ status: 'unavailable' });
    }
  });

  // Metrik Prometheus. Di production wajib memakai METRICS_TOKEN, jika tidak endpoint dimatikan.
  app.get('/metrics', async (req, res) => {
    if (config.metricsToken) {
      const presented = (req.get('authorization') || '').replace(/^Bearer /, '');
      if (!crypto.timingSafeEqual(sha256(presented), sha256(config.metricsToken))) {
        return res.status(401).set('WWW-Authenticate', 'Bearer').type('text/plain').send('unauthorized');
      }
    } else if (config.isProd) {
      return res.status(404).type('text/plain').send('not found');
    }
    res.set('Cache-Control', 'no-store').type(metrics.registry.contentType);
    return res.send(await metrics.registry.metrics());
  });

  app.use(
    '/api',
    limiter({
      windowMs: 60 * 1000,
      limit: config.rateLimit.apiMax,
      code: 'RATE_LIMITED',
      message: 'Terlalu banyak permintaan. Coba lagi sebentar.',
    }),
    express.json({ limit: '10kb' })
  );

  const authLimiter = limiter({
    windowMs: config.rateLimit.authWindowMs,
    limit: config.rateLimit.authMax,
    code: 'RATE_LIMITED',
    message: 'Terlalu banyak percobaan masuk atau daftar. Coba lagi dalam beberapa menit.',
  });
  app.use('/api/auth/login', authLimiter);
  app.use('/api/auth/register', authLimiter);
  app.use('/api/auth', authRouter);

  app.get('/api/products', (req, res) => res.json({ products: PRODUCTS }));

  app.use('/api', (req, res) =>
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Endpoint tidak ditemukan.' } })
  );

  app.use(express.static(publicDir, { extensions: ['html'], maxAge: config.isProd ? '1h' : 0 }));
  app.use((req, res) => res.status(404).type('text/plain').send('Halaman tidak ditemukan'));

  // Penangan galat: tidak pernah membocorkan stack trace ke klien.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: { code: 'BAD_JSON', message: 'Isi permintaan bukan JSON yang valid.' } });
    }
    if (err.type === 'entity.too.large') {
      return res.status(413).json({ error: { code: 'TOO_LARGE', message: 'Permintaan terlalu besar.' } });
    }
    logger.error('galat tak tertangani', { requestId: req.id, path: req.path, error: err.message, stack: err.stack });
    return res
      .status(500)
      .json({ error: { code: 'INTERNAL', message: 'Terjadi kesalahan di server.', requestId: req.id } });
  });

  return { app, db, logger, metrics, close: () => db.close() };
}

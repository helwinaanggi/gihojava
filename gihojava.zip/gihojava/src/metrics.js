import client from 'prom-client';

// Registry per aplikasi supaya pengujian tidak saling bentrok.
export function createMetrics() {
  const registry = new client.Registry();
  client.collectDefaultMetrics({ register: registry });

  const httpRequests = new client.Counter({
    name: 'http_requests_total',
    help: 'Jumlah request HTTP',
    labelNames: ['method', 'route', 'status'],
    registers: [registry],
  });

  const httpDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Durasi request HTTP dalam detik',
    labelNames: ['method', 'route', 'status'],
    buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
    registers: [registry],
  });

  const authEvents = new client.Counter({
    name: 'auth_events_total',
    help: 'Kejadian autentikasi (register, login_success, login_failed, account_locked, token_rejected)',
    labelNames: ['event'],
    registers: [registry],
  });

  return { registry, httpRequests, httpDuration, authEvents };
}

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };

// Log JSON satu baris per kejadian. Jangan pernah memasukkan kata sandi atau token ke fields.
export function createLogger(level = 'info') {
  const threshold = LEVELS[level] ?? LEVELS.info;

  function write(lvl, msg, fields) {
    if (LEVELS[lvl] < threshold) return;
    const line = JSON.stringify({ time: new Date().toISOString(), level: lvl, msg, ...fields });
    (lvl === 'error' ? process.stderr : process.stdout).write(line + '\n');
  }

  return {
    debug: (msg, fields = {}) => write('debug', msg, fields),
    info: (msg, fields = {}) => write('info', msg, fields),
    warn: (msg, fields = {}) => write('warn', msg, fields),
    error: (msg, fields = {}) => write('error', msg, fields),
  };
}

#!/usr/bin/env sh
# Membuat berkas rahasia untuk docker compose. Aman dijalankan ulang: berkas yang sudah ada tidak ditimpa.
set -eu
cd "$(dirname "$0")/.."
mkdir -p secrets
chmod 700 secrets

make_secret() {
  file="secrets/$1"
  if [ -f "$file" ]; then
    echo "sudah ada : $file (dilewati)"
  else
    # 644 di dalam folder secrets/ yang 700: container (pengguna non-root) tetap bisa membaca,
    # sedangkan pengguna lain di server tidak bisa masuk ke folder tersebut.
    umask 022
    openssl rand -hex 48 > "$file"
    echo "dibuat    : $file"
  fi
}

make_secret jwt_secret
make_secret metrics_token
make_secret grafana_password
echo "Kata sandi admin Grafana ada di secrets/grafana_password (pengguna: admin)."

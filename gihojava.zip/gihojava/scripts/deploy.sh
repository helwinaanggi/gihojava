#!/usr/bin/env sh
# Deploy di server: ambil kode/image terbaru, jalankan ulang, lalu pastikan sehat. Gagal sehat = keluar non-nol.
set -eu
cd "$(dirname "$0")/.."

[ -f secrets/jwt_secret ] || ./scripts/setup-secrets.sh

git pull --ff-only 2>/dev/null || echo "(bukan repo git, lewati git pull)"
docker compose pull --ignore-buildable 2>/dev/null || true
docker compose up -d --build --remove-orphans

echo "Menunggu aplikasi sehat..."
i=0
until [ "$(docker inspect -f '{{.State.Health.Status}}' "$(docker compose ps -q app)")" = "healthy" ]; do
  i=$((i + 1))
  if [ "$i" -gt 30 ]; then
    echo "GAGAL: aplikasi tidak sehat. Log terakhir:" >&2
    docker compose logs --tail=50 app >&2
    exit 1
  fi
  sleep 2
done
echo "Deploy selesai, aplikasi sehat."
docker image prune -f >/dev/null

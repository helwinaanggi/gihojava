# Gihojava

Toko web furnitur kayu jati. Lanjutan dari dokumen konsep, kini dengan akun pengguna (Daftar, Masuk, Akun), keamanan, deployment Docker, dan monitoring.

## Isi

| Bagian | Lokasi |
|---|---|
| API Express (auth, produk, health, metrics) | `src/` |
| Frontend statis (beranda, masuk, daftar, akun) | `public/` |
| Tes otomatis (20 kasus) | `test/` |
| Docker, Caddy (HTTPS), Compose | `Dockerfile`, `docker-compose.yml`, `Caddyfile` |
| Prometheus, aturan peringatan, Grafana | `monitoring/` |
| CI/CD GitHub Actions | `.github/workflows/ci.yml` |
| Skrip rahasia dan deploy | `scripts/` |

## Menjalankan lokal

Butuh Node.js 22.13 atau lebih baru.

```sh
npm install
npm test
npm start          # http://localhost:3000
```

Tanpa `JWT_SECRET`, mode development memakai secret acak sementara (token hilang saat restart). Untuk mengisinya: `JWT_SECRET=$(openssl rand -hex 48) npm start`.

## Alur autentikasi

1. `daftar.html` memanggil `POST /api/auth/register`. Server memvalidasi, menyimpan hash bcrypt, dan mengembalikan JWT.
2. `masuk.html` memanggil `POST /api/auth/login`. Server memverifikasi kata sandi dan mengembalikan JWT.
3. Klien menyimpan token di `localStorage` (kunci `gihojava_token`).
4. `akun.html` memanggil `GET /api/auth/me` dengan header `Authorization: Bearer <token>`. Server memverifikasi tanda tangan, penerbit, algoritma, dan masa berlaku, lalu memuat pengguna dari database. Tanpa token valid, halaman mengalihkan ke Masuk.
5. Keluar = menghapus token dari `localStorage` (token bersifat stateless).

### Endpoint

| Metode | Path | Keterangan |
|---|---|---|
| POST | `/api/auth/register` | `{name, email, password}` → 201 `{token, user}`; 409 email sudah ada; 422 data tidak valid |
| POST | `/api/auth/login` | `{email, password}` → 200 `{token, user}`; 401 kredensial salah/terkunci; 429 terlalu sering |
| GET | `/api/auth/me` | Bearer token → `{user}`; 401 jika tidak valid atau kedaluwarsa |
| GET | `/api/products` | Daftar produk contoh |
| GET | `/healthz` | Sehat jika database bisa diakses |
| GET | `/metrics` | Metrik Prometheus (butuh `METRICS_TOKEN`) |

## Keamanan yang sudah ada

- Kata sandi di-hash dengan bcrypt (cost 12). Minimal 10 karakter, ada huruf dan angka, maksimal 72 byte.
- JWT HS256 dengan algoritma dikunci, penerbit diperiksa, masa berlaku 2 jam. Secret wajib dan minimal 32 karakter di production (server menolak start jika tidak).
- Pesan login salah identik untuk email tak dikenal, kata sandi salah, dan akun terkunci. Waktu respons disamakan dengan hash palsu.
- Akun terkunci 15 menit setelah 5 kegagalan beruntun. Pembatas laju per IP: 20 percobaan masuk/daftar per 15 menit, 300 request API per menit.
- Email unik ditegakkan oleh database (UNIQUE + CHECK huruf kecil), `role` dibatasi CHECK dan tidak pernah diterima dari klien.
- Header keamanan lewat helmet: CSP ketat (tanpa skrip inline atau pihak ketiga), `nosniff`, `frame-ancestors 'none'`, HSTS di production.
- Batas ukuran body 10 KB, galat tidak membocorkan stack trace, log tidak memuat kata sandi atau token.
- Container non-root, filesystem read-only, semua capability dibuang.

### Tentang JWT di localStorage

Ini sesuai permintaan, tetapi ada kompromi yang perlu diketahui: skrip apa pun yang berjalan di halaman (misalnya hasil XSS) bisa membaca `localStorage`. Mitigasi di sini: CSP melarang skrip inline dan dari domain lain, data pengguna ditampilkan dengan `textContent`, dan token berumur pendek. Jika kelak toko menangani pembayaran atau data sensitif, pertimbangkan pindah ke cookie `HttpOnly; Secure; SameSite=Lax` (perubahan kecil: server mengirim `Set-Cookie`, klien berhenti menyimpan token).

## Deployment (satu server dengan Docker)

Prasyarat: server Linux dengan Docker Compose, domain yang mengarah ke IP server, port 80 dan 443 terbuka.

```sh
git clone <repo> /opt/gihojava && cd /opt/gihojava
./scripts/setup-secrets.sh                 # membuat secrets/jwt_secret, metrics_token, grafana_password
echo "DOMAIN=gihojava.example.com" > .env
./scripts/deploy.sh                        # build, jalankan, tunggu sehat
```

Caddy mengurus sertifikat HTTPS otomatis. `/metrics` tidak diekspos ke internet. Prometheus (127.0.0.1:9090) dan Grafana (127.0.0.1:3001) hanya bisa diakses dari server, misalnya lewat `ssh -L 3001:127.0.0.1:3001 user@server`.

Database SQLite ada di volume Docker `app-data`. Cadangkan secara berkala:

```sh
docker compose exec app node -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('/data/gihojava.db').exec(\"VACUUM INTO '/data/backup.db'\")"
docker cp "$(docker compose ps -q app)":/data/backup.db ./backup-$(date +%F).db
```

CI (`.github/workflows/ci.yml`): tes dan `npm audit` di setiap push, build dan push image ke GHCR di `main`. Deploy otomatis lewat SSH aktif jika variabel repo `DEPLOY_ENABLED=true` dan secret `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_KEY` diisi.

## Monitoring

- **Log**: JSON satu baris per kejadian (`docker compose logs -f app`), dengan `requestId` yang juga dikirim sebagai header `X-Request-Id`.
- **Metrik** (`/metrics`): `http_requests_total`, `http_request_duration_seconds`, `auth_events_total{event=...}`, plus metrik proses Node.
- **Peringatan** (`monitoring/alerts.yml`): aplikasi mati, 5xx di atas 5%, p95 di atas 1 detik, lonjakan login gagal, banyak akun terkunci, banyak token ditolak.
- **Healthcheck**: `/healthz` dipakai Docker dan `deploy.sh`.

Peringatan baru tampil di UI Prometheus. Untuk notifikasi ke email, Slack, atau WhatsApp, tambahkan Alertmanager (sudah ada kerangkanya di `prometheus.yml`).

## Yang belum ada (langkah berikutnya)

- Keranjang, checkout, pembayaran, dan pesanan (ini fitur MVP lain di dokumen konsep).
- Verifikasi email, lupa kata sandi, dan login OTP/Google.
- Peran admin dan halaman admin (kolom `role` sudah siap).
- Cadangan database otomatis dan Alertmanager.
- Jika trafik tumbuh atau perlu lebih dari satu server: pindah dari SQLite ke PostgreSQL.

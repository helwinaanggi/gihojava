import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import jwt from 'jsonwebtoken';
import { createApp } from '../src/app.js';
import { loadConfig } from '../src/config.js';

const SECRET = 'rahasia-pengujian-yang-cukup-panjang-1234567890';
const config = loadConfig({
  NODE_ENV: 'test',
  JWT_SECRET: SECRET,
  DB_PATH: ':memory:',
  BCRYPT_ROUNDS: '4',
  LOG_LEVEL: 'silent',
  METRICS_TOKEN: 'token-metrik',
  RATE_LIMIT_AUTH_MAX: '1000',
  RATE_LIMIT_API_MAX: '1000',
});

let server;
let base;
let ctx;

async function call(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* bukan JSON */
  }
  return { status: res.status, headers: res.headers, json, text };
}

const valid = { name: 'Rina Wulandari', email: 'rina@example.com', password: 'jatiasli2026' };

before(async () => {
  ctx = createApp(config);
  await new Promise((resolve) => {
    server = ctx.app.listen(0, '127.0.0.1', resolve);
  });
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
  ctx.close();
});

describe('registrasi', () => {
  it('membuat akun, mengembalikan token, dan tidak membocorkan hash', async () => {
    const r = await call('/api/auth/register', { method: 'POST', body: valid });
    assert.equal(r.status, 201);
    assert.ok(r.json.token);
    assert.equal(r.json.user.email, 'rina@example.com');
    assert.equal(r.json.user.role, 'customer');
    assert.equal(JSON.stringify(r.json).includes('password'), false);
  });

  it('menolak email yang sama, tanpa peduli huruf besar-kecil', async () => {
    const r = await call('/api/auth/register', { method: 'POST', body: { ...valid, email: ' RINA@Example.com ' } });
    assert.equal(r.status, 409);
    assert.equal(r.json.error.code, 'EMAIL_TAKEN');
  });

  it('menolak data tidak valid dengan pesan per kolom', async () => {
    const r = await call('/api/auth/register', {
      method: 'POST',
      body: { name: 'A', email: 'bukan-email', password: 'pendek' },
    });
    assert.equal(r.status, 422);
    assert.deepEqual(Object.keys(r.json.error.fields).sort(), ['email', 'name', 'password']);
  });

  it('menolak kata sandi tanpa angka', async () => {
    const r = await call('/api/auth/register', {
      method: 'POST',
      body: { ...valid, email: 'baru@example.com', password: 'hurufsajapanjang' },
    });
    assert.equal(r.status, 422);
    assert.ok(r.json.error.fields.password);
  });

  it('mengabaikan role yang dikirim klien (mass assignment)', async () => {
    const r = await call('/api/auth/register', {
      method: 'POST',
      body: { ...valid, email: 'cerdik@example.com', role: 'admin' },
    });
    assert.equal(r.status, 201);
    assert.equal(r.json.user.role, 'customer');
    assert.equal(jwt.decode(r.json.token).role, 'customer');
  });

  it('menjawab JSON rusak dengan 400, bukan 500', async () => {
    const res = await fetch(`${base}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{rusak',
    });
    assert.equal(res.status, 400);
  });
});

describe('login', () => {
  it('berhasil dengan kredensial benar (email tidak peka huruf besar)', async () => {
    const r = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'RINA@example.com', password: valid.password },
    });
    assert.equal(r.status, 200);
    assert.ok(r.json.token);
  });

  it('memberi jawaban identik untuk kata sandi salah dan email tak dikenal', async () => {
    const wrong = await call('/api/auth/login', { method: 'POST', body: { email: valid.email, password: 'salahsalah1' } });
    const unknown = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'tidak-ada@example.com', password: 'salahsalah1' },
    });
    assert.equal(wrong.status, 401);
    assert.equal(unknown.status, 401);
    assert.deepEqual(wrong.json, unknown.json);
  });

  it('mengunci akun sementara setelah 5 kegagalan, meski kata sandi benar', async () => {
    await call('/api/auth/register', {
      method: 'POST',
      body: { name: 'Dimas Pratama', email: 'dimas@example.com', password: 'kafejati2026' },
    });
    for (let i = 0; i < 5; i += 1) {
      const r = await call('/api/auth/login', {
        method: 'POST',
        body: { email: 'dimas@example.com', password: 'salahsalah1' },
      });
      assert.equal(r.status, 401);
    }
    const r = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'dimas@example.com', password: 'kafejati2026' },
    });
    assert.equal(r.status, 401);
    // Kunci dilepas: simulasikan masa kunci berakhir, lalu login benar harus berhasil.
    ctx.db.prepare('UPDATE users SET locked_until = ? WHERE email = ?').run(Date.now() - 1000, 'dimas@example.com');
    const ok = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'dimas@example.com', password: 'kafejati2026' },
    });
    assert.equal(ok.status, 200);
  });
});

describe('/api/auth/me', () => {
  let token;
  before(async () => {
    const r = await call('/api/auth/login', { method: 'POST', body: { email: valid.email, password: valid.password } });
    token = r.json.token;
  });

  it('mengembalikan profil untuk token valid', async () => {
    const r = await call('/api/auth/me', { token });
    assert.equal(r.status, 200);
    assert.equal(r.json.user.email, valid.email);
  });

  it('menolak tanpa token', async () => {
    const r = await call('/api/auth/me');
    assert.equal(r.status, 401);
  });

  it('menolak token yang dimodifikasi', async () => {
    const [h, p, s] = token.split('.');
    const tampered = `${h}.${p}.${s.slice(0, -2)}xx`;
    const r = await call('/api/auth/me', { token: tampered });
    assert.equal(r.status, 401);
    assert.equal(r.json.error.code, 'INVALID_TOKEN');
  });

  it('menolak token dengan algoritma "none"', async () => {
    const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const none = `${b64({ alg: 'none', typ: 'JWT' })}.${b64({ sub: '1', role: 'admin', iss: 'gihojava' })}.`;
    const r = await call('/api/auth/me', { token: none });
    assert.equal(r.status, 401);
  });

  it('menolak token yang ditandatangani secret lain', async () => {
    const forged = jwt.sign({ role: 'admin' }, 'secret-lain-yang-panjang-sekali-0000000000', {
      algorithm: 'HS256',
      issuer: 'gihojava',
      subject: '1',
    });
    const r = await call('/api/auth/me', { token: forged });
    assert.equal(r.status, 401);
  });

  it('menolak token kedaluwarsa dengan kode TOKEN_EXPIRED', async () => {
    const expired = jwt.sign({ role: 'customer' }, SECRET, {
      algorithm: 'HS256',
      issuer: 'gihojava',
      subject: '1',
      expiresIn: -10,
    });
    const r = await call('/api/auth/me', { token: expired });
    assert.equal(r.status, 401);
    assert.equal(r.json.error.code, 'TOKEN_EXPIRED');
  });
});

describe('keamanan dan observabilitas', () => {
  it('mengirim header keamanan dan CSP tanpa inline script', async () => {
    const r = await call('/healthz');
    const csp = r.headers.get('content-security-policy');
    assert.ok(csp.includes("script-src 'self'"));
    assert.equal(csp.includes("'unsafe-inline'") && /script-src[^;]*'unsafe-inline'/.test(csp), false);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(r.headers.get('x-powered-by'), null);
    assert.ok(r.headers.get('x-request-id'));
  });

  it('/healthz sehat dan menyentuh database', async () => {
    const r = await call('/healthz');
    assert.equal(r.status, 200);
    assert.equal(r.json.status, 'ok');
  });

  it('/metrics butuh token dan memuat metrik auth', async () => {
    const denied = await call('/metrics');
    assert.equal(denied.status, 401);
    const ok = await call('/metrics', { token: 'token-metrik' });
    assert.equal(ok.status, 200);
    assert.ok(ok.text.includes('auth_events_total{event="login_failed"}'));
    assert.ok(ok.text.includes('http_requests_total'));
  });

  it('rute /api yang tidak ada menjawab JSON 404', async () => {
    const r = await call('/api/tidak-ada');
    assert.equal(r.status, 404);
    assert.equal(r.json.error.code, 'NOT_FOUND');
  });

  it('daftar produk tersedia', async () => {
    const r = await call('/api/products');
    assert.equal(r.status, 200);
    assert.ok(r.json.products.length > 0);
  });
});

(function () {
  'use strict';
  var list = document.getElementById('product-list');
  var status = document.getElementById('product-status');
  var labels = { ready: 'Siap kirim', preorder: 'Pre-order 14 hari', low: 'Stok menipis' };
  var rupiah = new Intl.NumberFormat('id-ID');

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  fetch('/api/products', { headers: { Accept: 'application/json' } })
    .then(function (res) { if (!res.ok) throw new Error(); return res.json(); })
    .then(function (data) {
      status.hidden = true;
      data.products.forEach(function (p) {
        var card = el('article', 'pc');
        var img = el('div', 'img');
        img.setAttribute('role', 'img');
        img.setAttribute('aria-label', 'Contoh serat kayu jati untuk ' + p.name);
        var body = el('div', 'pcb');
        body.appendChild(el('span', 'pill ' + p.status, labels[p.status] || ''));
        body.appendChild(el('h3', '', p.name));
        body.appendChild(el('p', 'dim', p.dimensions + ' · ' + p.finishing));
        body.appendChild(el('p', 'price', 'Rp ' + rupiah.format(p.price)));
        card.appendChild(img);
        card.appendChild(body);
        list.appendChild(card);
      });
    })
    .catch(function () {
      status.textContent = 'Produk belum bisa dimuat. Coba muat ulang halaman.';
    });
})();

(function () {
  'use strict';
  var G = window.Gihojava;

  if (G.isLoggedIn()) {
    window.location.replace('/akun.html');
    return;
  }

  var form = document.getElementById('register-form');
  var name = document.getElementById('name');
  var email = document.getElementById('email');
  var password = document.getElementById('password');
  var confirmPw = document.getElementById('confirm');
  var submit = document.getElementById('submit');
  var alertBox = document.getElementById('alert');
  var meter = document.getElementById('meter-bar');
  var meterText = document.getElementById('meter-text');

  G.bindPasswordToggle(password, document.getElementById('toggle-pw'));

  // Aturan yang sama dengan server (server tetap penentu).
  function passwordProblem(value) {
    if (value.length < 10) return 'Kata sandi minimal 10 karakter.';
    if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) return 'Kata sandi harus mengandung huruf dan angka.';
    if (value.length > 72) return 'Kata sandi terlalu panjang (maksimal 72 karakter).';
    return '';
  }

  function strength(value) {
    if (passwordProblem(value)) return value.length === 0 ? 0 : 1;
    var score = 2;
    if (value.length >= 14 && /[^A-Za-z0-9]/.test(value)) score = 3;
    return score;
  }

  password.addEventListener('input', function () {
    var level = strength(password.value);
    meter.setAttribute('data-level', String(level));
    meterText.textContent = ['', 'Belum memenuhi syarat', 'Cukup', 'Kuat'][level];
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    G.showAlert(alertBox, '');
    [name, email, password, confirmPw].forEach(function (el) { G.setFieldError(el, ''); });

    var bad = false;
    var n = name.value.trim();
    if (n.length < 2 || n.length > 80) { G.setFieldError(name, 'Nama harus 2 sampai 80 karakter.'); bad = true; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) { G.setFieldError(email, 'Format email tidak valid.'); bad = true; }
    var pw = passwordProblem(password.value);
    if (pw) { G.setFieldError(password, pw); bad = true; }
    if (confirmPw.value !== password.value) { G.setFieldError(confirmPw, 'Kata sandi tidak sama.'); bad = true; }
    if (bad) return;

    submit.disabled = true;
    submit.textContent = 'Mendaftarkan...';
    G.register({ name: n, email: email.value.trim(), password: password.value }).then(function () {
      window.location.assign('/akun.html?baru=1');
    }).catch(function (err) {
      var fields = err.fields || {};
      ['name', 'email', 'password'].forEach(function (key) {
        if (fields[key]) G.setFieldError(document.getElementById(key), fields[key]);
      });
      G.showAlert(alertBox, err.message, false);
      submit.disabled = false;
      submit.textContent = 'Buat akun';
    });
  });
})();

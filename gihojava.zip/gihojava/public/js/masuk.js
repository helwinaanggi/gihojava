(function () {
  'use strict';
  var G = window.Gihojava;
  var params = new URLSearchParams(window.location.search);
  var next = G.safeNext(params.get('next'));

  if (G.isLoggedIn()) {
    window.location.replace(next);
    return;
  }

  var form = document.getElementById('login-form');
  var email = document.getElementById('email');
  var password = document.getElementById('password');
  var submit = document.getElementById('submit');
  var alertBox = document.getElementById('alert');

  G.bindPasswordToggle(password, document.getElementById('toggle-pw'));

  if (params.get('keluar')) G.showAlert(alertBox, 'Anda sudah keluar.', true);
  else if (params.get('sesi')) G.showAlert(alertBox, 'Sesi Anda berakhir. Silakan masuk lagi.', false);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    G.showAlert(alertBox, '');
    G.setFieldError(email, '');
    G.setFieldError(password, '');

    var bad = false;
    if (!email.value.trim()) { G.setFieldError(email, 'Email wajib diisi.'); bad = true; }
    if (!password.value) { G.setFieldError(password, 'Kata sandi wajib diisi.'); bad = true; }
    if (bad) return;

    submit.disabled = true;
    submit.textContent = 'Memeriksa...';
    G.login({ email: email.value.trim(), password: password.value }).then(function () {
      window.location.assign(next);
    }).catch(function (err) {
      G.showAlert(alertBox, err.message, false);
      password.value = '';
      password.focus();
      submit.disabled = false;
      submit.textContent = 'Masuk';
    });
  });
})();

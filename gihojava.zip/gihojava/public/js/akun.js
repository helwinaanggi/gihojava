(function () {
  'use strict';
  var G = window.Gihojava;

  // Halaman terlindungi: tanpa token valid, arahkan ke Masuk dan ingat tujuan.
  if (!G.isLoggedIn()) {
    window.location.replace('/masuk.html?next=' + encodeURIComponent('/akun.html'));
    return;
  }

  var alertBox = document.getElementById('alert');
  var card = document.getElementById('profile');
  var params = new URLSearchParams(window.location.search);
  if (params.get('baru')) G.showAlert(alertBox, 'Akun berhasil dibuat. Selamat datang di Gihojava.', true);

  var roles = { customer: 'Pelanggan', admin: 'Admin' };

  function put(id, text) {
    document.getElementById(id).textContent = text; // textContent, bukan innerHTML
  }

  // Token diverifikasi server di setiap pemanggilan /api/auth/me.
  G.me().then(function (user) {
    put('p-name', user.name);
    put('p-email', user.email);
    put('p-role', roles[user.role] || user.role);
    put('p-since', new Date(user.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }));
    put('greeting', 'Halo, ' + user.name.split(' ')[0]);
    card.hidden = false;
  }).catch(function (err) {
    if (err.status === 401) {
      window.location.replace('/masuk.html?sesi=1&next=' + encodeURIComponent('/akun.html'));
      return;
    }
    G.showAlert(alertBox, err.message, false);
  });
})();

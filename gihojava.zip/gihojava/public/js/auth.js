/* Klien autentikasi Gihojava.
 * Token JWT disimpan di localStorage (sesuai kebutuhan proyek). Risikonya: skrip apa pun yang berjalan di
 * halaman bisa membacanya. Karena itu CSP melarang skrip inline/pihak ketiga dan semua data pengguna
 * ditampilkan lewat textContent, tidak pernah innerHTML. Verifikasi sebenarnya selalu di server. */
(function () {
  'use strict';

  var KEY = 'gihojava_token';

  function storage() {
    try { return window.localStorage; } catch (e) { return null; }
  }
  function getToken() {
    var s = storage();
    return s ? s.getItem(KEY) : null;
  }
  function setToken(token) {
    var s = storage();
    if (s) s.setItem(KEY, token);
  }
  function clearToken() {
    var s = storage();
    if (s) s.removeItem(KEY);
  }

  // Hanya untuk UX (menyembunyikan menu, mengalihkan halaman). Bukan pemeriksaan keamanan.
  function decode(token) {
    try {
      var part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      var json = decodeURIComponent(atob(part).split('').map(function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(json);
    } catch (e) { return null; }
  }
  function isLoggedIn() {
    var token = getToken();
    if (!token) return false;
    var payload = decode(token);
    if (!payload || !payload.exp || payload.exp * 1000 <= Date.now()) {
      clearToken();
      return false;
    }
    return true;
  }

  // Cegah open redirect: hanya path relatif satu situs yang boleh jadi tujuan.
  function safeNext(value) {
    return typeof value === 'string' && /^\/(?!\/)[^\\]*$/.test(value) ? value : '/akun.html';
  }

  function request(path, options) {
    options = options || {};
    var headers = { Accept: 'application/json' };
    if (options.body) headers['Content-Type'] = 'application/json';
    if (options.auth) {
      var token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
    }
    return fetch(path, {
      method: options.method || 'GET',
      headers: headers,
      body: options.body ? JSON.stringify(options.body) : undefined,
      credentials: 'same-origin'
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) {
          var info = data && data.error ? data.error : {};
          var err = new Error(info.message || 'Terjadi kesalahan. Coba lagi.');
          err.status = res.status;
          err.code = info.code;
          err.fields = info.fields || {};
          throw err;
        }
        return data;
      });
    }, function () {
      throw new Error('Tidak bisa terhubung ke server. Periksa koneksi Anda.');
    });
  }

  function register(body) {
    return request('/api/auth/register', { method: 'POST', body: body }).then(function (data) {
      setToken(data.token);
      return data.user;
    });
  }
  function login(body) {
    return request('/api/auth/login', { method: 'POST', body: body }).then(function (data) {
      setToken(data.token);
      return data.user;
    });
  }
  function me() {
    return request('/api/auth/me', { auth: true }).then(function (data) { return data.user; }, function (err) {
      if (err.status === 401) clearToken();
      throw err;
    });
  }
  function logout() {
    clearToken();
  }

  // Bantuan formulir.
  function setFieldError(input, message) {
    var out = document.getElementById('err-' + input.id);
    input.setAttribute('aria-invalid', message ? 'true' : 'false');
    if (out) out.textContent = message || '';
  }
  function showAlert(el, message, ok) {
    el.hidden = !message;
    el.textContent = message || '';
    el.className = 'alert' + (ok ? ' ok' : '');
  }
  function bindPasswordToggle(input, button) {
    button.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      button.textContent = show ? 'Sembunyikan' : 'Tampilkan';
      button.setAttribute('aria-pressed', String(show));
    });
  }

  // Menu header: tampilkan Masuk/Daftar untuk tamu, Akun/Keluar untuk pengguna masuk.
  function syncNav() {
    var loggedIn = isLoggedIn();
    document.querySelectorAll('[data-auth="guest"]').forEach(function (el) { el.hidden = loggedIn; });
    document.querySelectorAll('[data-auth="user"]').forEach(function (el) { el.hidden = !loggedIn; });
  }
  document.addEventListener('DOMContentLoaded', function () {
    syncNav();
    document.querySelectorAll('[data-logout]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        logout();
        window.location.assign('/masuk.html?keluar=1');
      });
    });
  });
  // Sinkron antar tab: keluar di satu tab ikut mengeluarkan tab lain.
  window.addEventListener('storage', function (e) {
    if (e.key === KEY) syncNav();
  });

  window.Gihojava = {
    getToken: getToken, isLoggedIn: isLoggedIn, safeNext: safeNext,
    register: register, login: login, me: me, logout: logout,
    request: request, setFieldError: setFieldError, showAlert: showAlert,
    bindPasswordToggle: bindPasswordToggle
  };
})();

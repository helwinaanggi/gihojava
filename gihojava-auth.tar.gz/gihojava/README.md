# gihojava: autentikasi JWT

```bash
npm install
JWT_SECRET=$(openssl rand -hex 32) npm start   # http://localhost:3000
```

Produksi: set `NODE_ENV=production` dan `JWT_SECRET` (server menolak start tanpa itu).

| Endpoint | Fungsi |
|---|---|
| `POST /api/auth/register` `{nama,email,password}` | buat akun, balas `{token,user}` |
| `POST /api/auth/login` `{email,password}` | balas `{token,user}` |
| `GET /api/auth/me` (header `Authorization: Bearer <token>`) | verifikasi token, balas `{user}` |

Frontend: `public/index.html` (rute `#/masuk`, `#/daftar`, `#/akun`). Token disimpan di `localStorage` (`gj_token`).
Pengguna disimpan di `data/users.json` (kata sandi di-hash bcrypt); ganti dengan database sungguhan untuk produksi.

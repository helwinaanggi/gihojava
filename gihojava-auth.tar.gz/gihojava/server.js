'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'users.json');

let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    console.error('JWT_SECRET wajib diatur di produksi.');
    process.exit(1);
  }
  JWT_SECRET = crypto.randomBytes(32).toString('hex'); // dev: token hangus saat server restart
  console.warn('[dev] JWT_SECRET tidak diatur, memakai secret acak sementara.');
}

/* ---------- penyimpanan sederhana (berkas JSON) ---------- */
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
let users = [];
try { users = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { users = []; }
function persist() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(users, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
const publicUser = u => ({ id: u.id, nama: u.nama, email: u.email });

/* ---------- util ---------- */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// hash palsu agar waktu respons login tidak membocorkan apakah email terdaftar
const DUMMY_HASH = bcrypt.hashSync('dummy-password', 10);
const signToken = u => jwt.sign({ sub: u.id }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN, algorithm: 'HS256' });

function auth(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!m) return res.status(401).json({ error: 'Token tidak ada.' });
  try {
    const p = jwt.verify(m[1], JWT_SECRET, { algorithms: ['HS256'] });
    const u = users.find(x => x.id === p.sub);
    if (!u) return res.status(401).json({ error: 'Akun tidak ditemukan.' });
    req.user = u;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Token tidak valid atau kedaluwarsa.' });
  }
}

/* ---------- app ---------- */
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '10kb' }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.' },
});

app.post('/api/auth/register', authLimiter, async (req, res) => {
  const nama = String((req.body || {}).nama || '').trim();
  const email = String((req.body || {}).email || '').trim().toLowerCase();
  const password = String((req.body || {}).password || '');
  const errors = {};
  if (nama.length < 2 || nama.length > 60) errors.nama = 'Isi nama (2–60 karakter).';
  if (!EMAIL_RE.test(email) || email.length > 120) errors.email = 'Isi email yang valid, contoh nama@email.com.';
  if (password.length < 8 || password.length > 72) errors.password = 'Kata sandi 8–72 karakter.';
  if (Object.keys(errors).length) return res.status(400).json({ error: 'Data belum valid.', errors });
  if (users.some(u => u.email === email)) {
    return res.status(409).json({ error: 'Email sudah terdaftar.', errors: { email: 'Email sudah terdaftar. Silakan masuk.' } });
  }
  const user = {
    id: crypto.randomUUID(), nama, email,
    passwordHash: await bcrypt.hash(password, 10), createdAt: new Date().toISOString(),
  };
  users.push(user);
  persist();
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const email = String((req.body || {}).email || '').trim().toLowerCase();
  const password = String((req.body || {}).password || '');
  const u = users.find(x => x.email === email);
  const ok = await bcrypt.compare(password, u ? u.passwordHash : DUMMY_HASH);
  if (!u || !ok) return res.status(401).json({ error: 'Email atau kata sandi salah.' });
  res.json({ token: signToken(u), user: publicUser(u) });
});

app.get('/api/auth/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));

app.use('/api', (req, res) => res.status(404).json({ error: 'Tidak ditemukan.' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON tidak valid.' });
  console.error(err);
  res.status(500).json({ error: 'Terjadi kesalahan server.' });
});

if (require.main === module) app.listen(PORT, () => console.log('gihojava berjalan di http://localhost:' + PORT));
module.exports = app;

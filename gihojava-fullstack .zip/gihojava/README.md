# gihojava — Toko Furnitur Kayu Jati (Fullstack, siap Vercel)

Frontend statis (`public/index.html`) + API serverless Node.js (`api/`) dengan autentikasi JWT.

## Struktur
```
public/index.html        Frontend toko (katalog, keranjang, checkout) + halaman Masuk/Daftar/Akun
api/auth/register.js     POST  daftar akun (bcrypt) -> JWT
api/auth/login.js        POST  verifikasi email+sandi -> JWT
api/auth/me.js           GET   validasi token, ambil profil (butuh JWT)
api/orders.js            GET/POST pesanan milik pengguna (butuh JWT)
api/_lib/                db (Upstash Redis), helper http & JWT
test/smoke.js            tes backend lokal
vercel.json              output dir + header keamanan
```

## Fitur autentikasi
- Token JWT (HS256, default 7 hari) disimpan di `localStorage` (`gj_token`).
- Setiap request API membawa `Authorization: Bearer <token>`.
- **Proteksi route frontend**: `#/checkout`, `#/pesanan/...`, `#/akun` butuh login; belum login diarahkan ke `#/masuk?next=...` dan kembali ke tujuan setelah login. `#/masuk` dan `#/daftar` dialihkan jika sudah login.
- **Proteksi di backend**: `/api/orders` dan `/api/auth/me` menolak (401) tanpa token valid; pesanan hanya bisa dibaca pemiliknya.
- Token kedaluwarsa / tidak valid otomatis membuat pengguna keluar.

## Deploy ke Vercel
1. Push folder ini ke GitHub, lalu **Add New → Project** di vercel.com dan import repo. Framework preset: **Other** (tanpa build command).
2. Di project Vercel → **Storage** → buat/hubungkan **Upstash Redis** (Marketplace). Variabel `KV_REST_API_URL` / `KV_REST_API_TOKEN` (atau `UPSTASH_REDIS_REST_*`) terisi otomatis.
3. Di **Settings → Environment Variables** tambahkan:
   - `JWT_SECRET` = string acak ≥ 32 karakter  
     `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   - (opsional) `JWT_EXPIRES_IN` = `7d`
4. Deploy. Atau via CLI: `npm i -g vercel && vercel --prod`.

> Vercel tidak punya disk permanen, karena itu data pengguna disimpan di Redis.

## Jalan lokal
```bash
npm install
npm test                 # tes backend (DB memori)
npm i -g vercel
cp .env.example .env.local   # isi JWT_SECRET (+ Upstash bila ingin data permanen)
vercel dev               # http://localhost:3000
```
Tanpa env Upstash, mode dev memakai memori (data hilang saat restart). Di production env wajib diisi, kalau tidak API mengembalikan error.

## Catatan keamanan
- `localStorage` bisa dibaca skrip apa pun di halaman jika terjadi XSS. Semua teks dinamis di frontend sudah di-escape; jangan menambah `innerHTML` dari input pengguna tanpa `esc()`. Alternatif yang lebih aman: cookie `HttpOnly`.
- Total harga pesanan dihitung di klien karena katalog masih statis. Untuk produksi sungguhan, pindahkan katalog ke server dan hitung ulang di `api/orders.js`.
- Tambahkan rate limiting (mis. `@upstash/ratelimit`) pada `/api/auth/login` untuk mencegah brute force.

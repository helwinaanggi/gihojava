// Lapisan penyimpanan: Upstash Redis (production) atau memori (dev lokal tanpa env).
const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;

let impl;

if (url && token) {
  const { Redis } = require('@upstash/redis');
  const r = new Redis({ url, token });
  impl = {
    get: (k) => r.get(k),
    // true jika berhasil dibuat, false jika key sudah ada
    setNX: async (k, v) => (await r.set(k, v, { nx: true })) === 'OK',
    set: (k, v) => r.set(k, v),
    lpush: (k, v) => r.lpush(k, v),
    lrange: (k, a, b) => r.lrange(k, a, b),
  };
} else {
  if (process.env.VERCEL_ENV === 'production' || process.env.NODE_ENV === 'production') {
    throw new Error('Database belum dikonfigurasi: set UPSTASH_REDIS_REST_URL dan UPSTASH_REDIS_REST_TOKEN.');
  }
  console.warn('[db] Env Upstash tidak ada, memakai penyimpanan MEMORI (data hilang saat restart).');
  const g = globalThis.__gjmem || (globalThis.__gjmem = { kv: new Map(), lists: new Map() });
  const clone = (v) => (v === undefined ? null : JSON.parse(JSON.stringify(v)));
  impl = {
    get: async (k) => (g.kv.has(k) ? clone(g.kv.get(k)) : null),
    setNX: async (k, v) => (g.kv.has(k) ? false : (g.kv.set(k, clone(v)), true)),
    set: async (k, v) => (g.kv.set(k, clone(v)), 'OK'),
    lpush: async (k, v) => {
      const l = g.lists.get(k) || [];
      l.unshift(clone(v));
      g.lists.set(k, l);
      return l.length;
    },
    lrange: async (k, a, b) => {
      const l = g.lists.get(k) || [];
      return clone(l.slice(a, b === -1 ? undefined : b + 1));
    },
  };
}

module.exports = impl;

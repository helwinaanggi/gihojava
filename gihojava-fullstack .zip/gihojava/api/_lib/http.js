const jwt = require('jsonwebtoken');

const isProd = process.env.VERCEL_ENV === 'production' || process.env.NODE_ENV === 'production';

function secret() {
  const s = process.env.JWT_SECRET;
  if (s && s.length >= 32) return s;
  if (isProd) throw new Error('JWT_SECRET wajib diisi (minimal 32 karakter) di environment production.');
  return 'dev-only-secret-jangan-dipakai-di-production-0123456789';
}

const send = (res, status, body) => {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.send(JSON.stringify(body));
};

function body(req) {
  const b = req.body;
  if (!b) return {};
  if (typeof b === 'string') {
    try { return JSON.parse(b); } catch { return {}; }
  }
  return b;
}

// Bungkus handler: cek method, tangani error tak terduga.
const handler = (methods, fn) => async (req, res) => {
  try {
    if (!methods.includes(req.method)) {
      res.setHeader('Allow', methods.join(', '));
      return send(res, 405, { error: 'Metode tidak diizinkan.' });
    }
    await fn(req, res);
  } catch (e) {
    console.error(e);
    send(res, 500, { error: 'Terjadi kesalahan di server. Coba lagi sebentar.' });
  }
};

const signToken = (user) =>
  jwt.sign({ email: user.email, name: user.name }, secret(), {
    subject: user.id,
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    algorithm: 'HS256',
  });

// Mengembalikan payload JWT, atau mengirim 401 dan mengembalikan null.
function requireAuth(req, res) {
  const h = req.headers.authorization || '';
  const m = /^Bearer (.+)$/i.exec(h);
  if (!m) { send(res, 401, { error: 'Anda belum masuk.' }); return null; }
  try {
    return jwt.verify(m[1], secret(), { algorithms: ['HS256'] });
  } catch (e) {
    const expired = e.name === 'TokenExpiredError';
    send(res, 401, { error: expired ? 'Sesi berakhir, silakan masuk lagi.' : 'Token tidak valid.' });
    return null;
  }
}

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email });

module.exports = { send, body, handler, signToken, requireAuth, publicUser };

const crypto = require('crypto');
const db = require('./_lib/db');
const { send, body, handler, requireAuth } = require('./_lib/http');

const str = (v, max) => String(v == null ? '' : v).slice(0, max);
const num = (v) => (Number.isFinite(+v) ? Math.max(0, Math.round(+v)) : 0);

function orderNo() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `GJ-${String(d.getFullYear()).slice(2)}${p(d.getMonth() + 1)}${p(d.getDate())}-${crypto.randomInt(10000, 100000)}`;
}

// Semua endpoint di sini butuh JWT yang valid.
module.exports = handler(['GET', 'POST'], async (req, res) => {
  const me = requireAuth(req, res);
  if (!me) return;

  if (req.method === 'GET') {
    const no = req.query && req.query.no;
    if (no) {
      const o = await db.get('order:' + no);
      if (!o || o.userId !== me.sub) return send(res, 404, { error: 'Pesanan tidak ditemukan.' });
      return send(res, 200, { order: o });
    }
    const nos = await db.lrange('orders:' + me.sub, 0, 49);
    const orders = (await Promise.all(nos.map((n) => db.get('order:' + n)))).filter(Boolean);
    return send(res, 200, { orders });
  }

  const b = body(req);
  const items = Array.isArray(b.items) ? b.items.slice(0, 50) : [];
  if (!items.length) return send(res, 400, { error: 'Keranjang kosong.' });
  const cust = b.cust || {};
  if (!cust.nama || !cust.alamat) return send(res, 400, { error: 'Data pengiriman belum lengkap.' });

  const t = b.t || {};
  const order = {
    no: orderNo(),
    userId: me.sub,
    date: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
    createdAt: new Date().toISOString(),
    items: items.map((i) => ({
      name: str(i.name, 120), fin: str(i.fin, 40), size: str(i.size, 60), qty: num(i.qty), sub: num(i.sub),
    })),
    // Catatan: total dihitung di klien karena katalog masih statis di frontend.
    // Pindahkan katalog ke server bila ingin harga dihitung ulang di backend.
    t: { sub: num(t.sub), disc: num(t.disc), ship: num(t.ship), total: num(t.total) },
    method: str(b.method, 20),
    pay: str(b.pay, 20),
    cust: { nama: str(cust.nama, 80), alamat: str(cust.alamat, 300), zone: str(cust.zone, 80), pos: str(cust.pos, 5) },
    zone: str(b.zone, 20),
  };
  await db.set('order:' + order.no, order);
  await db.lpush('orders:' + me.sub, order.no);
  send(res, 201, { order });
});

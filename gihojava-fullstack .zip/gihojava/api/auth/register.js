const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../_lib/db');
const { send, body, handler, signToken, publicUser } = require('../_lib/http');

module.exports = handler(['POST'], async (req, res) => {
  const b = body(req);
  const name = String(b.name || '').trim();
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');

  const errors = {};
  if (name.length < 3 || name.length > 60) errors.name = 'Nama 3–60 karakter.';
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 120) errors.email = 'Format email belum benar.';
  if (password.length < 8 || password.length > 72 || !/[A-Za-z]/.test(password) || !/\d/.test(password))
    errors.password = 'Kata sandi 8–72 karakter, mengandung huruf dan angka.';
  if (Object.keys(errors).length) return send(res, 400, { error: 'Data belum valid.', errors });

  const user = {
    id: crypto.randomUUID(),
    name,
    email,
    passwordHash: await bcrypt.hash(password, 10),
    createdAt: new Date().toISOString(),
  };

  const created = await db.setNX('user:' + email, user);
  if (!created) return send(res, 409, { error: 'Email sudah terdaftar. Silakan masuk.', errors: { email: 'Email sudah terdaftar.' } });

  send(res, 201, { token: signToken(user), user: publicUser(user) });
});

const bcrypt = require('bcryptjs');
const db = require('../_lib/db');
const { send, body, handler, signToken, publicUser } = require('../_lib/http');

// Hash palsu agar waktu respons tetap mirip saat email tidak ditemukan.
const DUMMY = bcrypt.hashSync('dummy-password-untuk-timing', 10);

module.exports = handler(['POST'], async (req, res) => {
  const b = body(req);
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  if (!email || !password) return send(res, 400, { error: 'Isi email dan kata sandi.' });

  const user = await db.get('user:' + email);
  const ok = await bcrypt.compare(password, user ? user.passwordHash : DUMMY);
  if (!user || !ok) return send(res, 401, { error: 'Email atau kata sandi salah.' });

  send(res, 200, { token: signToken(user), user: publicUser(user) });
});

const db = require('../_lib/db');
const { send, handler, requireAuth, publicUser } = require('../_lib/http');

module.exports = handler(['GET'], async (req, res) => {
  const payload = requireAuth(req, res);
  if (!payload) return;
  const user = await db.get('user:' + payload.email);
  if (!user || user.id !== payload.sub) return send(res, 401, { error: 'Akun tidak ditemukan.' });
  send(res, 200, { user: publicUser(user) });
});

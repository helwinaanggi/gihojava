// Smoke test lokal: memanggil handler serverless langsung (memakai DB memori).
const assert = require('assert');
const register = require('../api/auth/register');
const login = require('../api/auth/login');
const me = require('../api/auth/me');
const orders = require('../api/orders');

function call(h, { method = 'GET', body, token, query } = {}) {
  return new Promise((resolve) => {
    const res = {
      _h: {}, code: 200,
      status(c) { this.code = c; return this; },
      setHeader(k, v) { this._h[k] = v; return this; },
      send(b) { resolve({ status: this.code, json: JSON.parse(b) }); },
    };
    const req = { method, body, query, headers: token ? { authorization: 'Bearer ' + token } : {} };
    h(req, res);
  });
}

(async () => {
  let r = await call(register, { method: 'POST', body: { name: 'Budi', email: 'x', password: '123' } });
  assert.equal(r.status, 400);

  r = await call(register, { method: 'POST', body: { name: 'Budi Santoso', email: 'Budi@Mail.com', password: 'rahasia123' } });
  assert.equal(r.status, 201); assert(r.json.token); assert(!r.json.user.passwordHash);
  const t1 = r.json.token;

  r = await call(register, { method: 'POST', body: { name: 'Budi Lagi', email: 'budi@mail.com', password: 'rahasia123' } });
  assert.equal(r.status, 409, 'email duplikat ditolak');

  r = await call(login, { method: 'POST', body: { email: 'budi@mail.com', password: 'salah12345' } });
  assert.equal(r.status, 401);
  r = await call(login, { method: 'POST', body: { email: 'tidak@ada.com', password: 'rahasia123' } });
  assert.equal(r.status, 401);
  r = await call(login, { method: 'POST', body: { email: 'budi@mail.com', password: 'rahasia123' } });
  assert.equal(r.status, 200); const t2 = r.json.token;

  r = await call(me); assert.equal(r.status, 401);
  r = await call(me, { token: 'abc.def.ghi' }); assert.equal(r.status, 401);
  r = await call(me, { token: t2 }); assert.equal(r.status, 200); assert.equal(r.json.user.email, 'budi@mail.com');

  r = await call(orders, { method: 'POST', body: {} }); assert.equal(r.status, 401, 'orders butuh JWT');
  const order = { items: [{ name: 'Meja', fin: 'Natural', qty: 1, sub: 1000000 }], t: { sub: 1000000, disc: 0, ship: 50000, total: 1050000 }, method: 'reguler', pay: 'transfer', cust: { nama: 'Budi', alamat: 'Jl. Mawar 12 Ungaran', zone: 'Jawa Tengah & DIY', pos: '50511' }, zone: 'jateng' };
  r = await call(orders, { method: 'POST', token: t2, body: order });
  assert.equal(r.status, 201); const no = r.json.order.no; assert(/^GJ-\d{6}-\d{5}$/.test(no));

  r = await call(orders, { token: t2 }); assert.equal(r.json.orders.length, 1);
  r = await call(orders, { token: t2, query: { no } }); assert.equal(r.status, 200);

  // pengguna lain tidak boleh melihat pesanan ini
  r = await call(register, { method: 'POST', body: { name: 'Sari Dewi', email: 'sari@mail.com', password: 'rahasia123' } });
  r = await call(orders, { token: r.json.token, query: { no } }); assert.equal(r.status, 404, 'isolasi antar pengguna');

  r = await call(login, { method: 'GET' }); assert.equal(r.status, 405);
  console.log('SEMUA TEST LULUS');
})().catch((e) => { console.error(e); process.exit(1); });

const express = require('express');
const cors = require('cors');
const path = require('path');
const products = require('./data/products.json');

const app = express();
const PORT = process.env.PORT || 3000;

// CORS: izinkan frontend dari origin lain (mis. Live Server di :5500)
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());

const price = (p) => Math.round((p.list * (1 - p.disc / 100)) / 1000) * 1000;
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

// Log sederhana tiap request
app.use((req, res, next) => {
  const t = Date.now();
  res.on('finish', () => console.log(`${req.method} ${req.originalUrl} -> ${res.statusCode} (${Date.now() - t} ms)`));
  next();
});

app.get('/api/health', (req, res) => res.json({ status: 'ok', products: products.length }));

// GET /api/products?q=&cat=&max=&fin=natural,madu&stock=true&rate=true&sort=low&page=1&limit=8
app.get('/api/products', (req, res) => {
  const { q = '', cat = 'all', sort = 'rel', fin = '' } = req.query;
  const max = Number(req.query.max) || Infinity;
  const page = clamp(parseInt(req.query.page) || 1, 1, 1e6);
  const limit = clamp(parseInt(req.query.limit) || 8, 1, 100);
  const fins = fin ? String(fin).split(',') : [];

  let items = products.filter((p) => {
    if (q && !`${p.name} ${p.cat} ${p.type}`.toLowerCase().includes(String(q).toLowerCase())) return false;
    if (cat !== 'all' && p.cat !== cat) return false;
    if (price(p) > max) return false;
    if (fins.length && !fins.some((f) => p.fins.includes(f))) return false;
    if (req.query.stock === 'true' && p.stock === 0) return false;
    if (req.query.rate === 'true' && p.rating < 4.7) return false;
    return true;
  });

  const sorters = {
    sold: (a, b) => b.sold - a.sold,
    rate: (a, b) => b.rating - a.rating,
    low: (a, b) => price(a) - price(b),
    high: (a, b) => price(b) - price(a),
  };
  if (sorters[sort]) items = [...items].sort(sorters[sort]);

  const total = items.length;
  const pages = Math.max(1, Math.ceil(total / limit));
  res.json({
    data: items.slice((page - 1) * limit, page * limit),
    meta: { total, page, pages, limit },
  });
});

// GET /api/products/:slug
app.get('/api/products/:slug', (req, res) => {
  const p = products.find((x) => x.slug === req.params.slug);
  if (!p) return res.status(404).json({ message: 'Produk tidak ditemukan' });
  res.json(p);
});

// Sajikan frontend dari folder public (same-origin, opsional)
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api', (req, res) => res.status(404).json({ message: 'Endpoint tidak ada' }));

app.listen(PORT, () => console.log(`API gihojava berjalan di http://localhost:${PORT}`));

# gihojava: backend API + frontend

    npm install
    node server.js          # http://localhost:3000

- Frontend : http://localhost:3000/
- API      : http://localhost:3000/api/products
- Detail   : http://localhost:3000/api/products/meja-makan-muria
- Frontend di server lain (mis. Live Server :5500)? Tambahkan sebelum script:
  <script>window.API_URL='http://localhost:3000/api'</script>

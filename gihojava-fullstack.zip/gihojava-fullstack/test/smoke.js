// Uji cepat tanpa database: memeriksa auth, validasi, dan rumus harga.
process.env.JWT_SECRET = 'rahasia-untuk-uji';
const assert = require('assert');
const jwt = require('jsonwebtoken');
const app = require('../src/app');
const { unitPrice, shippingCost, couponDiscount } = require('../src/utils/pricing');

let failed = 0;
const t = async (name, fn) => {
  try { await fn(); console.log('ok   ', name); } catch (e) { failed++; console.log('GAGAL', name, '\n      ', e.message); }
};

(async () => {
  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = (path, opts = {}) =>
    fetch(base + path, { ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) } })
      .then(async (r) => ({ status: r.status, body: await r.json().catch(() => null) }));
  const admin = jwt.sign({ id: '64b000000000000000000001', role: 'admin' }, process.env.JWT_SECRET);
  const customer = jwt.sign({ id: '64b000000000000000000002', role: 'customer' }, process.env.JWT_SECRET);

  await t('GET /api/health = 200', async () => assert.strictEqual((await call('/api/health')).status, 200));
  await t('rute tidak dikenal = 404', async () => assert.strictEqual((await call('/api/xyz')).status, 404));
  await t('POST produk tanpa token = 401', async () =>
    assert.strictEqual((await call('/api/products', { method: 'POST', body: '{}' })).status, 401));
  await t('token palsu = 401', async () =>
    assert.strictEqual((await call('/api/products', { method: 'POST', body: '{}', headers: { Authorization: 'Bearer palsu' } })).status, 401));
  await t('token bukan admin = 403', async () =>
    assert.strictEqual((await call('/api/products', { method: 'POST', body: '{}', headers: { Authorization: 'Bearer ' + customer } })).status, 403));
  await t('DELETE produk tanpa token = 401', async () =>
    assert.strictEqual((await call('/api/products/64b000000000000000000009', { method: 'DELETE' })).status, 401));
  await t('GET daftar pesanan tanpa token = 401', async () =>
    assert.strictEqual((await call('/api/orders')).status, 401));
  await t('admin + produk kosong = 400 dengan daftar galat', async () => {
    const r = await call('/api/products', { method: 'POST', body: '{}', headers: { Authorization: 'Bearer ' + admin } });
    assert.strictEqual(r.status, 400);
    assert.ok(r.body.errors.some((e) => e.field === 'name'));
  });
  await t('admin + kategori di luar daftar = 400', async () => {
    const r = await call('/api/products', { method: 'POST', headers: { Authorization: 'Bearer ' + admin },
      body: JSON.stringify({ name: 'Uji', category: 'dapur', type: 'table', listPrice: 1000 }) });
    assert.strictEqual(r.status, 400);
    assert.ok(r.body.errors.some((e) => e.field === 'category'));
  });
  await t('login dengan objek (injeksi) = 400', async () =>
    assert.strictEqual((await call('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: { $gt: '' }, password: { $gt: '' } }) })).status, 400));
  await t('JSON rusak = 400', async () =>
    assert.strictEqual((await call('/api/orders', { method: 'POST', body: '{rusak' })).status, 400));
  await t('pesanan kosong = 400 dengan galat per kolom', async () => {
    const r = await call('/api/orders', { method: 'POST', body: '{}' });
    assert.strictEqual(r.status, 400);
    const f = r.body.errors.map((e) => e.field);
    ['nama', 'wa', 'alamat', 'zone', 'pos', 'items'].forEach((k) => assert.ok(f.includes(k), 'kurang ' + k));
  });
  await t('bayar di tempat di luar Jateng = 400', async () => {
    const r = await call('/api/orders', { method: 'POST', body: JSON.stringify({
      customer: { nama: 'Budi Santoso', wa: '081234567890', alamat: 'Jalan Mawar 12 Jakarta', zone: 'jawa', pos: '12345' },
      shipping: 'reguler', payment: 'cod', items: [{ productId: '64b000000000000000000009', qty: 1 }] }) });
    assert.strictEqual(r.status, 400);
    assert.ok(r.body.errors.some((e) => e.field === 'payment'));
  });
  await t('nomor pesanan salah format = 404', async () =>
    assert.strictEqual((await call('/api/orders/abc')).status, 404));

  await t('harga: Meja Muria 180 cm diskon 10% = Rp8.010.000', () =>
    assert.strictEqual(unitPrice({ listPrice: 8900000, discount: 10 }, { priceDelta: 0 }), 8010000));
  await t('harga: Lemari 3 pintu diskon 15% = Rp10.625.000', () =>
    assert.strictEqual(unitPrice({ listPrice: 12500000, discount: 15 }, { priceDelta: 0 }), 10625000));
  await t('ongkir: 62 kg ke Jateng = Rp174.000', () => assert.strictEqual(shippingCost('jateng', 62, 'reguler'), 174000));
  await t('ongkir ekspres = reguler x 1,4 dibulatkan ribuan', () => assert.strictEqual(shippingCost('jateng', 62, 'ekspres'), 244000));
  await t('kupon JATI10 = 10%', () => assert.strictEqual(couponDiscount('JATI10', 8010000), 801000));
  await t('kupon HEMAT500 butuh belanja min. Rp5.000.000', () => {
    assert.strictEqual(couponDiscount('HEMAT500', 4999000), 0);
    assert.strictEqual(couponDiscount('HEMAT500', 5000000), 500000);
  });
  await t('kupon "__proto__" ditolak', () => assert.strictEqual(couponDiscount('__proto__', 9000000), 0));

  server.close();
  console.log(failed ? `\n${failed} uji gagal` : '\nSemua uji lulus');
  process.exit(failed ? 1 : 0);
})();

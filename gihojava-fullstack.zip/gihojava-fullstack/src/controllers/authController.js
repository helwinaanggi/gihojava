const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// dipakai agar waktu respons sama baik email ada maupun tidak
const DUMMY_HASH = bcrypt.hashSync('tidak-dipakai', 12);

const sign = (user) =>
  jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES || '8h',
  });

// POST /api/auth/login
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    // harus teks, supaya objek seperti {"$gt":""} tidak bisa menyusup ke query
    if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
      return res.status(400).json({ message: 'Email dan kata sandi wajib diisi' });
    }
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
    const ok = user ? await user.matches(password) : (await bcrypt.compare(password, DUMMY_HASH), false);
    if (!ok) return res.status(401).json({ message: 'Email atau kata sandi salah' });
    res.json({ token: sign(user), user: { name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
};

// GET /api/auth/me
exports.me = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(401).json({ message: 'Akun tidak ditemukan' });
    res.json({ user: { name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
};

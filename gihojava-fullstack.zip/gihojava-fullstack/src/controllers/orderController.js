const crypto = require('crypto');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const Order = require('../models/Order');
const { ZONES, isZone, unitPrice, shippingCost, couponDiscount } = require('../utils/pricing');

const PHONE = /^(\+62|62|0)8\d{7,11}$/;
const EMAIL = /^\S+@\S+\.\S+$/;
const ORDER_NO = /^GJ-\d{6}-[0-9A-F]{8}$/;
const s = (v) => (typeof v === 'string' ? v.trim() : '');

const genOrderNo = () => {
  const d = new Date();
  const ymd = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  return `GJ-${ymd}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
};

function validate(b) {
  const errors = [];
  const c = b.customer && typeof b.customer === 'object' ? b.customer : {};
  if (s(c.nama).length < 3) errors.push({ field: 'nama', message: 'Isi nama lengkap, minimal 3 huruf.' });
  if (!PHONE.test(s(c.wa).replace(/[\s-]/g, ''))) errors.push({ field: 'wa', message: 'Nomor WhatsApp belum benar. Contoh: 081234567890.' });
  if (s(c.email) && !EMAIL.test(s(c.email))) errors.push({ field: 'email', message: 'Format email belum benar.' });
  if (s(c.alamat).length < 10) errors.push({ field: 'alamat', message: 'Tulis alamat selengkapnya, minimal 10 karakter.' });
  if (!isZone(c.zone)) errors.push({ field: 'zone', message: 'Pilih wilayah pengiriman.' });
  if (!/^\d{5}$/.test(s(c.pos))) errors.push({ field: 'pos', message: 'Kode pos terdiri dari 5 angka.' });
  if (!['reguler', 'ekspres'].includes(b.shipping)) errors.push({ field: 'shipping', message: 'Pilih jenis pengiriman.' });
  if (!['transfer', 'qris', 'dp', 'cod'].includes(b.payment)) errors.push({ field: 'payment', message: 'Pilih metode pembayaran.' });
  if (b.payment === 'cod' && c.zone !== 'jateng') errors.push({ field: 'payment', message: 'Bayar di tempat hanya untuk Jawa Tengah & DIY.' });
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 50) {
    errors.push({ field: 'items', message: 'Keranjang kosong atau terlalu banyak item.' });
  } else {
    b.items.forEach((it, i) => {
      const ok = it && typeof it.productId === 'string' && mongoose.isValidObjectId(it.productId)
        && Number.isInteger(it.qty) && it.qty >= 1 && it.qty <= 99;
      if (!ok) errors.push({ field: `items[${i}]`, message: 'Item pesanan tidak valid.' });
    });
  }
  return errors;
}

// mengembalikan stok yang sudah dipesan; aman dipanggil dua kali
async function release(list) {
  while (list.length) {
    const l = list.pop();
    await Product.updateOne({ _id: l.product }, { $inc: { stock: l.qty, sold: -l.qty } });
  }
}

// bentuk data yang aman dikirim ke publik (tanpa telepon dan email)
const toPublic = (o) => ({
  orderNo: o.orderNo,
  date: o.createdAt,
  status: o.status,
  items: o.items.map((i) => ({
    name: i.name, finish: i.finish, sizeLabel: i.sizeLabel, qty: i.qty, unitPrice: i.unitPrice, lineTotal: i.lineTotal,
  })),
  totals: o.totals,
  shippingMethod: o.shippingMethod,
  paymentMethod: o.paymentMethod,
  zone: o.customer.zone,
  customer: {
    name: o.customer.name,
    address: o.customer.address,
    zoneName: o.customer.zoneName,
    postalCode: o.customer.postalCode,
  },
});

// CREATE: POST /api/orders (publik, dibatasi laju)
exports.createOrder = async (req, res, next) => {
  const reserved = [];
  try {
    const b = req.body && typeof req.body === 'object' ? req.body : {};
    const errors = validate(b);
    if (errors.length) return res.status(400).json({ message: 'Data pesanan belum lengkap', errors });
    const c = b.customer;

    const ids = [...new Set(b.items.map((i) => i.productId))];
    const products = await Product.find({ _id: { $in: ids } });
    const byId = new Map(products.map((p) => [String(p._id), p]));

    const lines = [];
    for (const it of b.items) {
      const p = byId.get(it.productId);
      if (!p) return res.status(404).json({ message: 'Ada produk yang sudah tidak dijual. Muat ulang halaman.' });
      if (!p.finishes.includes(it.finish)) {
        return res.status(400).json({ message: `Finishing untuk ${p.name} tidak tersedia` });
      }
      let size = null;
      if (p.sizes.length) {
        size = p.sizes.find((x) => x.key === it.size);
        if (!size) return res.status(400).json({ message: `Pilih ukuran untuk ${p.name}` });
      }
      const unit = unitPrice(p, size);
      lines.push({
        product: p._id, name: p.name, finish: it.finish,
        sizeKey: size ? size.key : undefined, sizeLabel: size ? size.label : undefined,
        qty: it.qty, unitPrice: unit, lineTotal: unit * it.qty, weight: p.weight || 0,
      });
    }

    // kurangi stok secara atomik per item; bila ada yang kurang, kembalikan semuanya
    for (const l of lines) {
      const r = await Product.updateOne(
        { _id: l.product, stock: { $gte: l.qty } },
        { $inc: { stock: -l.qty, sold: l.qty } }
      );
      if (r.modifiedCount !== 1) {
        await release(reserved);
        return res.status(409).json({ message: `Stok ${l.name} tidak cukup. Jumlah di keranjang disesuaikan.` });
      }
      reserved.push(l);
    }

    const subtotal = lines.reduce((a, l) => a + l.lineTotal, 0);
    const kg = lines.reduce((a, l) => a + l.weight * l.qty, 0);
    const code = s(b.coupon).toUpperCase();
    const discount = couponDiscount(code, subtotal);
    const shipping = shippingCost(c.zone, kg, b.shipping);
    const totals = { subtotal, discount, shipping, total: subtotal - discount + shipping };

    let order;
    for (let attempt = 0; attempt < 3 && !order; attempt++) {
      try {
        order = await Order.create({
          orderNo: genOrderNo(),
          items: lines,
          customer: {
            name: s(c.nama), phone: s(c.wa).replace(/[\s-]/g, ''), email: s(c.email) || undefined,
            address: s(c.alamat), zone: c.zone, zoneName: ZONES[c.zone].name, postalCode: s(c.pos), note: s(c.note).slice(0, 300) || undefined,
          },
          shippingMethod: b.shipping,
          paymentMethod: b.payment,
          coupon: discount ? code : undefined,
          totals,
        });
      } catch (e) {
        if (!(e && e.code === 11000 && attempt < 2)) throw e; // nomor bentrok: coba lagi
      }
    }
    res.status(201).json(toPublic(order));
  } catch (err) {
    await release(reserved).catch(() => {});
    next(err);
  }
};

// READ (publik, lewat nomor pesanan): GET /api/orders/:no
exports.getOrderByNo = async (req, res, next) => {
  try {
    const no = String(req.params.no || '').toUpperCase();
    if (!ORDER_NO.test(no)) return res.status(404).json({ message: 'Pesanan tidak ditemukan' });
    const order = await Order.findOne({ orderNo: no });
    if (!order) return res.status(404).json({ message: 'Pesanan tidak ditemukan' });
    res.json(toPublic(order));
  } catch (err) {
    next(err);
  }
};

// READ (admin): GET /api/orders?status=&page=&limit=
exports.listOrders = async (req, res, next) => {
  try {
    const status = typeof req.query.status === 'string' ? req.query.status : undefined;
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 20, 1), 100);
    const filter = Order.STATUSES.includes(status) ? { status } : {};
    const [data, total] = await Promise.all([
      Order.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
      Order.countDocuments(filter),
    ]);
    res.json({ data, meta: { total, page, pages: Math.ceil(total / limit) || 1 } });
  } catch (err) {
    next(err);
  }
};

// UPDATE (admin): PATCH /api/orders/:id/status  { "status": "diproses" }
exports.updateStatus = async (req, res, next) => {
  try {
    const status = req.body && req.body.status;
    if (!Order.STATUSES.includes(status)) {
      return res.status(400).json({ message: `Status harus salah satu dari: ${Order.STATUSES.join(', ')}` });
    }
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Pesanan tidak ditemukan' });
    if (order.status === 'dibatalkan') return res.status(409).json({ message: 'Pesanan yang dibatalkan tidak bisa diubah' });

    // update bersyarat agar pembatalan ganda tidak mengembalikan stok dua kali
    const updated = await Order.findOneAndUpdate(
      { _id: order._id, status: { $ne: 'dibatalkan' } },
      { status },
      { new: true }
    );
    if (!updated) return res.status(409).json({ message: 'Pesanan sudah dibatalkan' });

    if (status === 'dibatalkan') {
      for (const i of updated.items) {
        await Product.updateOne({ _id: i.product }, { $inc: { stock: i.qty, sold: -i.qty } });
      }
    }
    res.json(updated);
  } catch (err) {
    next(err);
  }
};

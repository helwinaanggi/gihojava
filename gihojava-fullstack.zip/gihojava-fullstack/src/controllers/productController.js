const mongoose = require('mongoose');
const Product = require('../models/Product');

const ALLOWED = [
  'name', 'category', 'type', 'listPrice', 'discount', 'stock', 'weight',
  'dims', 'finishes', 'sizes', 'defaultSize', 'description',
];
const pick = (body) =>
  Object.fromEntries(Object.entries(body || {}).filter(([k]) => ALLOWED.includes(k)));

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// query harus berupa teks biasa, bukan objek (mencegah injeksi operator MongoDB)
const str = (v) => (typeof v === 'string' ? v : undefined);

const SORTS = {
  rel: { createdAt: 1 },
  sold: { sold: -1 },
  rate: { rating: -1 },
  low: { listPrice: 1 },
  high: { listPrice: -1 },
};

// READ (daftar): GET /api/products?q=&category=&maxPrice=&finish=&inStock=&sort=&page=&limit=
exports.getProducts = async (req, res, next) => {
  try {
    const q = str(req.query.q);
    const category = str(req.query.category);
    const finish = str(req.query.finish);
    const maxPrice = str(req.query.maxPrice);
    const sort = str(req.query.sort) || 'rel';
    const page = Math.max(parseInt(str(req.query.page)) || 1, 1);
    const limit = Math.min(Math.max(parseInt(str(req.query.limit)) || 8, 1), 50);

    const filter = {};
    if (q) filter.name = { $regex: escapeRegex(q), $options: 'i' };
    if (category) filter.category = category;
    if (finish) filter.finishes = finish;
    if (str(req.query.inStock) === 'true') filter.stock = { $gt: 0 };
    if (maxPrice && Number.isFinite(Number(maxPrice))) {
      filter.$expr = {
        $lte: [
          { $multiply: ['$listPrice', { $subtract: [1, { $divide: ['$discount', 100] }] }] },
          Number(maxPrice),
        ],
      };
    }

    const [data, total] = await Promise.all([
      Product.find(filter).sort(SORTS[sort] || SORTS.rel).skip((page - 1) * limit).limit(limit),
      Product.countDocuments(filter),
    ]);
    res.json({ data, meta: { total, page, pages: Math.ceil(total / limit) || 1 } });
  } catch (err) {
    next(err);
  }
};

// READ (detail): GET /api/products/:id  (_id MongoDB atau slug)
exports.getProduct = async (req, res, next) => {
  try {
    const { id } = req.params;
    const product = mongoose.isValidObjectId(id)
      ? await Product.findById(id)
      : await Product.findOne({ slug: id });
    if (!product) return res.status(404).json({ message: 'Produk tidak ditemukan' });
    res.json(product);
  } catch (err) {
    next(err);
  }
};

// CREATE: POST /api/products (admin)
exports.createProduct = async (req, res, next) => {
  try {
    const product = await Product.create(pick(req.body));
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
};

// UPDATE: PUT /api/products/:id (admin)
exports.updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Produk tidak ditemukan' });
    product.set(pick(req.body));
    await product.save(); // menjalankan validasi dan memperbarui slug bila nama berubah
    res.json(product);
  } catch (err) {
    next(err);
  }
};

// DELETE: DELETE /api/products/:id (admin)
exports.deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Produk tidak ditemukan' });
    res.json({ message: 'Produk dihapus', id: product._id });
  } catch (err) {
    next(err);
  }
};

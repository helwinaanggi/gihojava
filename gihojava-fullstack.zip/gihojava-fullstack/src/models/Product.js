const mongoose = require('mongoose');
const slugify = require('slugify');

const FINISHES = ['natural', 'madu', 'walnut', 'hitam'];
const CATEGORIES = ['makan', 'tamu', 'tidur', 'kerja', 'teras'];
// jenis dipakai website untuk memilih ilustrasi produk
const TYPES = ['table', 'chair', 'wardrobe', 'bed', 'shelf', 'coffee', 'bench', 'desk', 'lounge', 'console', 'nightstand', 'garden'];

const sizeSchema = new mongoose.Schema(
  {
    key: { type: String, required: true },
    label: { type: String, required: true },
    priceDelta: { type: Number, default: 0 },
    override: { width: Number, depth: Number, height: Number },
  },
  { _id: false }
);

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Nama produk wajib diisi'], trim: true, maxlength: 120 },
    slug: { type: String, unique: true, index: true },
    category: { type: String, required: [true, 'Kategori wajib diisi'], enum: CATEGORIES },
    type: { type: String, required: [true, 'Jenis produk wajib diisi'], enum: TYPES },
    listPrice: { type: Number, required: [true, 'Harga wajib diisi'], min: [0, 'Harga tidak boleh negatif'] },
    discount: { type: Number, default: 0, min: 0, max: 90 },
    stock: { type: Number, default: 0, min: [0, 'Stok tidak boleh negatif'] },
    weight: { type: Number, default: 0, min: 0 },
    dims: { width: Number, depth: Number, height: Number },
    finishes: { type: [{ type: String, enum: FINISHES }], default: ['natural'] },
    sizes: [sizeSchema],
    defaultSize: { type: Number, default: 0, min: 0 },
    description: [String],
    rating: { type: Number, default: 0, min: 0, max: 5 },
    sold: { type: Number, default: 0, min: 0 },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

productSchema.virtual('price').get(function () {
  return Math.round((this.listPrice * (1 - this.discount / 100)) / 1000) * 1000;
});

productSchema.pre('validate', function () {
  if (this.isModified('name') || !this.slug) {
    this.slug = slugify(this.name || '', { lower: true, strict: true });
  }
});

const Product = mongoose.model('Product', productSchema);
Product.FINISHES = FINISHES;
Product.CATEGORIES = CATEGORIES;
Product.TYPES = TYPES;
module.exports = Product;

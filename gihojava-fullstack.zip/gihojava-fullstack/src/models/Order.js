const mongoose = require('mongoose');

const STATUSES = ['menunggu_pembayaran', 'diproses', 'dikirim', 'selesai', 'dibatalkan'];

const itemSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name: String,
    finish: String,
    sizeKey: String,
    sizeLabel: String,
    qty: { type: Number, required: true, min: 1 },
    unitPrice: Number,
    lineTotal: Number,
    weight: Number,
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    orderNo: { type: String, unique: true, index: true },
    items: { type: [itemSchema], validate: (v) => v.length > 0 },
    customer: {
      name: { type: String, required: true },
      phone: { type: String, required: true },
      email: String,
      address: { type: String, required: true },
      zone: { type: String, required: true },
      zoneName: String,
      postalCode: { type: String, required: true },
      note: String,
    },
    shippingMethod: { type: String, enum: ['reguler', 'ekspres'], required: true },
    paymentMethod: { type: String, enum: ['transfer', 'qris', 'dp', 'cod'], required: true },
    coupon: String,
    totals: { subtotal: Number, discount: Number, shipping: Number, total: Number },
    status: { type: String, enum: STATUSES, default: 'menunggu_pembayaran', index: true },
  },
  { timestamps: true }
);

const Order = mongoose.model('Order', orderSchema);
Order.STATUSES = STATUSES;
module.exports = Order;

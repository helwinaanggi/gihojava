// Mengisi database dengan produk contoh dan akun admin.
// PERINGATAN: menghapus semua produk yang ada. Jangan dijalankan di database produksi yang sudah berisi data.
require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('./models/Product');
const User = require('./models/User');
const products = require('./data/products.json');

(async () => {
  const { MONGODB_URI, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (!MONGODB_URI) throw new Error('MONGODB_URI belum diisi di .env');
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 8) {
    throw new Error('Isi ADMIN_EMAIL dan ADMIN_PASSWORD (minimal 8 karakter) di .env');
  }
  await mongoose.connect(MONGODB_URI);

  await Product.deleteMany();
  for (const item of products) await Product.create(item); // satu per satu agar slug terbentuk
  console.log(`${products.length} produk dimasukkan`);

  const email = ADMIN_EMAIL.toLowerCase();
  const existing = await User.findOne({ email });
  if (existing) {
    existing.password = ADMIN_PASSWORD;
    existing.role = 'admin';
    await existing.save();
    console.log(`Kata sandi admin ${email} diperbarui`);
  } else {
    await User.create({ name: 'Admin gihojava', email, password: ADMIN_PASSWORD, role: 'admin' });
    console.log(`Admin dibuat: ${email}`);
  }
  await mongoose.disconnect();
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});

// Satu-satunya sumber kebenaran untuk harga, ongkir, dan kupon.
// Website memakai rumus yang sama untuk tampilan, tetapi total pesanan selalu dihitung ulang di sini.
const ZONES = {
  jateng: { name: 'Jawa Tengah & DIY', base: 50000, perKg: 2000, days: '2–4 hari' },
  jawa: { name: 'Jawa lainnya (Jabodetabek, Jabar, Jatim, Banten)', base: 150000, perKg: 3000, days: '3–6 hari' },
  bali: { name: 'Bali & Nusa Tenggara', base: 350000, perKg: 6000, days: '7–12 hari' },
  sumatera: { name: 'Sumatera', base: 400000, perKg: 7000, days: '7–14 hari' },
  kalimantan: { name: 'Kalimantan', base: 450000, perKg: 8000, days: '8–14 hari' },
  sulawesi: { name: 'Sulawesi, Maluku & Papua', base: 550000, perKg: 10000, days: '10–18 hari' },
};

const COUPONS = {
  JATI10: { pct: 10, label: 'Diskon 10%' },
  HEMAT500: { off: 500000, min: 5000000, label: 'Potongan Rp500.000 (min. belanja Rp5.000.000)' },
};

const roundK = (n) => Math.round(n / 1000) * 1000;

const isZone = (k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(ZONES, k);

// harga satuan setelah diskon, dibulatkan ke ribuan
const unitPrice = (product, size) =>
  roundK((product.listPrice + (size ? size.priceDelta || 0 : 0)) * (1 - (product.discount || 0) / 100));

const shippingCost = (zoneKey, totalKg, method) => {
  const z = ZONES[zoneKey];
  const cost = z.base + z.perKg * Math.ceil(totalKg);
  return method === 'ekspres' ? roundK(cost * 1.4) : cost;
};

const couponDiscount = (code, subtotal) => {
  if (!Object.prototype.hasOwnProperty.call(COUPONS, code)) return 0;
  const c = COUPONS[code];
  if (subtotal < (c.min || 0)) return 0;
  return c.pct ? Math.round((subtotal * c.pct) / 100) : c.off;
};

module.exports = { ZONES, COUPONS, isZone, unitPrice, shippingCost, couponDiscount };

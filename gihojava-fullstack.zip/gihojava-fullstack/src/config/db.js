const mongoose = require('mongoose');

module.exports = async function connectDB() {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI);
    console.log(`MongoDB terhubung: ${conn.connection.host}`);
  } catch (err) {
    console.error('Koneksi MongoDB gagal:', err.message);
    process.exit(1);
  }
};

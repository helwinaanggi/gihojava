const rateLimit = require('express-rate-limit');

const make = (windowMs, limit, message) =>
  rateLimit({ windowMs, limit, standardHeaders: true, legacyHeaders: false, message: { message } });

exports.loginLimiter = make(15 * 60 * 1000, 10, 'Terlalu banyak percobaan masuk. Coba lagi 15 menit lagi.');
exports.orderLimiter = make(60 * 1000, 20, 'Terlalu banyak pesanan dalam waktu singkat. Coba lagi sebentar.');

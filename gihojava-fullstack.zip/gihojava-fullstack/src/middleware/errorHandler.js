module.exports = (err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Isi permintaan bukan JSON yang valid' });
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ message: 'Isi permintaan terlalu besar' });
  }
  if (err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
    return res.status(400).json({ message: 'Data tidak valid', errors });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ message: `Format ${err.path} tidak valid` });
  }
  if (err.code === 11000) {
    return res.status(409).json({ message: 'Data dengan nilai yang sama sudah ada (nama, slug, atau email)' });
  }
  console.error(err);
  res.status(500).json({ message: 'Terjadi kesalahan di server' });
};

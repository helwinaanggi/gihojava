const jwt = require('jsonwebtoken');

// Memeriksa token JWT di header: Authorization: Bearer <token>
exports.protect = (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Masuk dulu untuk melanjutkan' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.id, role: payload.role };
    next();
  } catch (e) {
    res.status(401).json({ message: 'Sesi berakhir, silakan masuk lagi' });
  }
};

exports.adminOnly = (req, res, next) => {
  if (req.user && req.user.role === 'admin') return next();
  res.status(403).json({ message: 'Hanya admin yang boleh melakukan ini' });
};

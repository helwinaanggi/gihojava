const router = require('express').Router();
const c = require('../controllers/orderController');
const { protect, adminOnly } = require('../middleware/auth');
const { orderLimiter } = require('../middleware/limiters');

router.route('/').post(orderLimiter, c.createOrder).get(protect, adminOnly, c.listOrders);
router.patch('/:id/status', protect, adminOnly, c.updateStatus);
router.get('/:no', c.getOrderByNo);

module.exports = router;

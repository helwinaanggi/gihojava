# gihojava: toko furnitur kayu jati (Express + MongoDB)

Satu proyek berisi API, website toko, dan halaman admin.

## Menjalankan

Butuh Node.js 18+ dan MongoDB (lokal atau MongoDB Atlas).

```bash
npm install
cp .env.example .env        # lalu isi MONGODB_URI, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm run seed                # memasukkan 12 produk contoh dan membuat akun admin
npm run dev                 # atau: npm start
```

Buka:

- Toko: http://localhost:5000
- Admin: http://localhost:5000/admin.html (masuk dengan ADMIN_EMAIL dan ADMIN_PASSWORD)

Catatan: `npm run seed` menghapus semua produk yang ada. Jangan dijalankan di database yang sudah berisi data asli.

Membuat JWT_SECRET:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

## Endpoint

| Metode | URL | Akses | Fungsi |
|---|---|---|---|
| GET | /api/health | publik | cek server |
| POST | /api/auth/login | publik (maks. 10 per 15 menit) | masuk, mengembalikan token JWT |
| GET | /api/auth/me | token | data akun |
| GET | /api/products | publik | daftar, dengan q, category, maxPrice, finish, inStock, sort, page, limit |
| GET | /api/products/:idOrSlug | publik | detail produk |
| POST | /api/products | admin | tambah produk |
| PUT | /api/products/:id | admin | ubah produk |
| DELETE | /api/products/:id | admin | hapus produk |
| POST | /api/orders | publik (maks. 20 per menit) | buat pesanan, stok berkurang |
| GET | /api/orders/:no | publik, lewat nomor pesanan | lihat pesanan (tanpa telepon dan email) |
| GET | /api/orders | admin | daftar pesanan, filter status |
| PATCH | /api/orders/:id/status | admin | ubah status, pembatalan mengembalikan stok |

Token dikirim lewat header `Authorization: Bearer <token>`.

## Cara kerja pesanan

- Harga, ongkir, dan kupon dihitung ulang di server (`src/utils/pricing.js`). Angka dari browser tidak dipercaya.
- Stok dikurangi per item dengan satu perintah atomik (`stock >= qty`). Bila satu item gagal, item yang sudah dikurangi dikembalikan.
- Transaksi MongoDB tidak dipakai karena butuh replica set. Pengembalian stok dilakukan manual di kode.

## Struktur

```
server.js              titik masuk (baca .env, sambung DB, listen)
src/app.js             Express: middleware, rute, file statis
src/config/db.js       koneksi MongoDB
src/models/            Product, User, Order
src/controllers/       logika produk, auth, pesanan
src/routes/            peta URL
src/middleware/        auth JWT, batas laju, penanganan galat
src/utils/pricing.js   harga, ongkir, kupon
src/data/products.json data contoh untuk seed
src/seed.js            isi database
public/index.html      website toko
public/admin.html      halaman admin
test/smoke.js          uji tanpa database (npm test)
```

## Keamanan yang sudah ada

Kata sandi di-hash (bcrypt), token JWT berumur 8 jam, query diperiksa agar tidak bisa disusupi operator MongoDB, field produk dibatasi (whitelist), batas laju untuk login dan pesanan, header keamanan lewat helmet.

## Belum ada

- Pembayaran sungguhan (saat ini pesanan berstatus "menunggu pembayaran" dan dikonfirmasi manual oleh admin).
- Ulasan produk masih tersimpan di peramban, belum di database.
- Pengiriman email atau WhatsApp otomatis, dan lupa kata sandi.
- Content-Security-Policy dimatikan karena website memakai skrip inline. Aktifkan bila skrip dipisah ke file.
- Gunakan HTTPS di server produksi. Token admin disimpan di sessionStorage peramban.

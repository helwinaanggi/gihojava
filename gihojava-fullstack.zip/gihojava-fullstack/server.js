require('dotenv').config();

if (!process.env.JWT_SECRET) {
  console.error('JWT_SECRET belum diisi. Salin .env.example menjadi .env lalu isi nilainya.');
  process.exit(1);
}

const app = require('./src/app');
const connectDB = require('./src/config/db');

const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));
});
